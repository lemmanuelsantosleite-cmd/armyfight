# Relatório de auditoria estática — Army Fight Club

## Escopo e limites

Revisão estática do código-fonte e das migrações SQL disponíveis no ZIP. Não foi possível concluir `npm install`; portanto, o build, ESLint, TypeScript e testes de integração não foram executados. Não houve conexão com o banco de produção nem teste com contas reais. As alterações desta cópia precisam ser validadas em ambiente de teste antes de substituir o site publicado.

## Correções preventivas aplicadas nesta cópia

1. **Escopo entre academias em ações administrativas de aluno** (`src/lib/alunos.functions.ts`): redefinir senha e excluir aluno agora verificam o papel do operador e confirmam que o aluno pertence à mesma academia, exceto para o Super Administrador. Antes, a verificação de papel aceitava qualquer Mestre, sem comparar a academia do aluno.
2. **Proteção da função de estatísticas do Hub** (`src/lib/hub.functions.ts`): `getHubPortalData` agora exige sessão válida e papel `super` antes de usar o cliente de serviço que ignora RLS.
3. **Proteção de configuração**: `.gitignore` exclui `.env` e variantes, mantendo `.env.example` sem valores secretos. O `.env` original não foi incluído nesta cópia.

## Achados que exigem atenção

### Alto — abuso de endpoints públicos

- `solicitarCadastro` cria usuários via chave administrativa e não possui rate limit, CAPTCHA ou fluxo de aprovação antiabuso no próprio endpoint. Pode ser abusado para criar muitas contas.
- `solicitarAcademia` permite solicitações públicas de academia com a chave administrativa e também não mostra proteção contra automação. O status `pendente` reduz o risco de ativação automática, mas não impede spam.
- `resolverLoginAcademia` consulta perfis com privilégios administrativos e devolve o e-mail interno real quando encontra o nome. Isso pode permitir enumeração de nomes/cadastros e exposição de e-mails internos. Corrigir isso exige rever o fluxo de login nome + senha para não quebrar a autenticação atual.
- `resolveSuperEmail` é público e procura contas Super pelo nome/usuário, devolvendo o e-mail real. Isso facilita descoberta do identificador de uma conta privilegiada. Recomenda-se substituir o fluxo por autenticação no servidor ou um identificador público não sensível, com proteção contra tentativas automatizadas.

### Alto — revisão obrigatória de isolamento multiacademia

- As migrações habilitam RLS explicitamente nas 19 tabelas identificadas, o que é positivo. Isso não prova, por si só, que todas as políticas estão corretas.
- As políticas e funções `SECURITY DEFINER` precisam ser testadas com duas academias, especialmente alterações em `user_roles`, `profiles`, mensalidades, presenças, exames, graduações, certificados, notificações, objetivos e técnicas.
- `src/lib/tenant.ts` guarda a academia ativa em variável global de módulo no cliente. Isso pode servir para estado da interface, mas **não deve ser considerado uma barreira de segurança**; o banco/RLS e as verificações de servidor precisam impor o escopo independentemente desse estado.
- A criação de papéis deve confirmar tanto a academia indicada quanto a academia real do usuário-alvo. A revisão estática encontrou políticas de papel que precisam de teste de abuso cruzado antes de produção.

### Médio — tratamento de erros e consistência

- Várias consultas administrativas usam `supabaseAdmin`; esse cliente ignora RLS. Cada chamada precisa de autenticação e autorização explícitas no servidor. Foi adicionada proteção à função `getHubPortalData`; os fluxos públicos de cadastro/login continuam pendentes de revisão arquitetural.
- Algumas consultas tratam dados ausentes como listas vazias (`data ?? []`) sem sempre propagar erros. Isso pode fazer a interface parecer vazia em caso de falha de rede/permissão, em vez de mostrar um erro claro.
- Há uso de `any` em verificação de permissões em `alunos.functions.ts`. A alteração preserva isso por enquanto para não arriscar uma mudança ampla de tipos sem conseguir rodar o TypeScript.
- O código de captura de erros e `console.error` merece uma revisão de produção para confirmar que não envia tokens, dados pessoais ou segredos para logs. Não foi confirmado vazamento de segredo nesses arquivos.

## Verificações realizadas

- Inventário de rotas, funções de servidor, clientes Supabase e migrações.
- Busca de operações CRUD, uso do cliente administrativo, funções de autorização, `SECURITY DEFINER`, políticas RLS e referências a variáveis de ambiente.
- Identificadas 19 tabelas no conjunto de migrações; todas têm uma instrução explícita de habilitação de RLS.
- A cópia de trabalho não contém `.env`; foi adicionado `.env.example` com nomes de variáveis vazios.
- A instalação de dependências excedeu o tempo limite. **Build, lint, checagem de tipos, testes automatizados, login real, CRUD real e isolamento entre duas academias continuam não verificados.**

## Próximos testes obrigatórios antes de publicar

1. Rodar instalação, build, ESLint e TypeScript em ambiente de desenvolvimento.
2. Criar duas academias de teste (A e B) com Mestre e aluno em cada uma.
3. Tentar ler, editar, redefinir senha e excluir aluno da academia B estando autenticado como Mestre da A; todas as ações devem falhar.
4. Repetir testes para mensalidades, presenças, exames, graduações, certificados, notificações, objetivos, conquistas, faixas, técnicas e tickets.
5. Testar login, cadastro, recuperação de sessão e logout no Android e navegador.
6. Adicionar rate limiting e proteção antiabuso aos endpoints públicos e revisar o fluxo que revela e-mails internos.
7. Validar migrações e políticas em banco de teste antes de aplicar qualquer SQL em produção.

## Importante

Este ZIP é uma **cópia de auditoria com correções pontuais**, não uma certificação de segurança nem uma versão pronta para produção. Não substitua o site atual por ele até concluir os testes acima.
