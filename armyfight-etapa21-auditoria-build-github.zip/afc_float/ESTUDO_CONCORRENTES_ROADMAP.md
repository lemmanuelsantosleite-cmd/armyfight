# Army Fight Club / Martial Hub — estudo comparativo e roadmap de produto

**Versão:** 0.1 — 10/10/2026  
**Base:** inspeção estática do repositório + páginas públicas dos fornecedores.  
**Limites:** não temos acesso ao código privado, arquitetura interna ou dados operacionais dos concorrentes; não foi conectado banco de produção nem executado teste de ponta a ponta. Recursos dos concorrentes abaixo são declarações dos próprios fornecedores, não auditoria independente.

## 1. Objetivo de produto

Evoluir o Army Fight Club de uma experiência centrada em técnicas/faixas e painéis de aluno/admin para uma plataforma de operação diária de academias de artes marciais. O sistema deve ser configurável por academia e modalidade, seguro em multi-tenant, utilizável primeiro no Android via web responsiva/PWA e preparado para crescer sem reescrever todos os módulos.

## 2. O que a inspeção do repositório mostra hoje

- Stack: React/TypeScript, TanStack Start, Vite e Supabase.
- Rotas principais: `/academia`, `/belt/$beltId`, `/admin`, `/aluno`, `/hub`, `/super`, além de entrada/criação de academia atualmente redirecionadas/desativadas.
- As telas existentes já apontam para técnicas/faixas, perfis, mensalidades, presenças, exames, graduações, objetivos, certificados, notificações, academias e suporte/comunicados do Hub.
- As migrações ativam RLS em várias tabelas, mas a presença de RLS não comprova que todas as políticas estão corretas ou que o estado publicado corresponde ao repositório.
- Há funções de servidor com acesso administrativo e fluxos públicos que exigem revisão de autorização e antiabuso.
- A aplicação parece ter elementos de modo de academia única, enquanto a visão futura exige multiacademia real.

**Não comprovado nesta versão:** build, lint, typecheck, testes de integração, funcionamento real de pagamentos, isolamento entre academias em produção, app nativo, automações ou integração de mensagens.

## 3. Comparação de capacidades divulgadas publicamente

| Área | Gymdesk | Kicksite | Spark Membership | Implicação para Army Fight Club |
|---|---|---|---|---|
| Gestão de alunos/membros | Sim | Sim | Sim, CRM com perfil unificado | Perfil central do aluno, sem duplicar dados em cada módulo |
| Presença/check-in | Sim | Quiosque, PIN/código de barras e histórico | Check-in conectado ao perfil e automações | Presença rápida no celular, histórico confiável e relatórios |
| Faixas/progressão | Promoções/programas | Currículo, exames, elegibilidade e histórico | Histórico de faixa e regras ligadas à jornada do aluno | Currículo configurável por modalidade e trilha auditável de graduação |
| Cobrança/financeiro | Pagamentos recorrentes e cobrança | Faturas, recorrência e atrasos | Cobrança, checkout, relatórios e POS | Começar com controle financeiro; integrar provedor depois, sem guardar cartão |
| Agenda/reservas | Reservas e aulas | Calendário, eventos e inscrição | Agenda, reservas e eventos | Agenda por turma/modalidade, limites de vagas e prevenção de conflito |
| Comunicação | Marketing e comunicação | E-mail/SMS e lembretes | Mensagens, campanhas e workflows | Notificações internas primeiro; canais externos após avaliar custo/consentimento |
| Interessados/CRM | Marketing/leads | Captura e acompanhamento de leads | Pipeline de prospectos, aulas experimentais e ex-alunos | CRM como módulo próprio, conectado à matrícula e frequência |
| Famílias/responsáveis | Gestão de membros | Perfis familiares | Contas familiares | Relação responsável-aluno com permissões próprias, especialmente para menores |
| Portal/app | Recursos móveis/check-in | Portal web móvel | Aplicativo iOS/Android e recursos de gestão | Experiência móvel responsiva primeiro; validar PWA antes de app nativo |
| Estoque/vendas | POS/mercadorias anunciado | Inventário/mercadorias anunciado | POS e estoque anunciado | Futuro opcional; não bloquear o núcleo do produto |
| Migração/onboarding | Verificar por plano/processo | Verificar com fornecedor | Fornecedor divulga suporte de migração | Importação CSV com pré-visualização, validação e relatório de erros |

### Fontes públicas dos fornecedores

- Gymdesk — https://gymdesk.com/software/martial-arts
- Kicksite — https://kicksite.com/faq/ e https://kicksite.com/martial-arts-management-software/
- Spark Membership — https://sparkmembership.com/platform e https://sparkmembership.com/platform/spark-crm

Não inferir arquitetura interna a partir de páginas de marketing. A coluna final contém recomendações para o nosso produto, não afirmações sobre código dos concorrentes.

## 4. Arquitetura-alvo recomendada

### 4.1 Camadas

1. **Interface por papel:** Mestre/dono, administrador com permissões atribuídas, instrutor, aluno e responsável; Super Admin separado do contexto de uma academia.
2. **Serviços de domínio:** funções server-side para operações críticas; validação de identidade, papel, academia e entrada antes de qualquer alteração.
3. **Dados multi-tenant:** cada registro de negócio associado à academia; RLS com escopo de academia e usuário; políticas antigas amplas removidas apenas por migração revisada e testada.
4. **Eventos/auditoria:** trilha de ações sensíveis (ator, ação, entidade, data, resultado), sem senhas, tokens ou segredos.
5. **Integrações:** pagamentos, e-mail, SMS/push e calendário através de adaptadores, sem amarrar regras de negócio a um único fornecedor.
6. **Operação:** migrações versionadas, backups, logs, monitoramento e procedimento de recuperação testado.

### 4.2 Princípios de dados

- `academia_id` não é confiável só porque veio do navegador; o servidor deve derivar ou validar o escopo pelo usuário autenticado.
- Permissões não podem depender apenas de esconder botões ou redirecionar páginas.
- Operações `INSERT`/`UPDATE` precisam validar também o registro novo (`WITH CHECK` em RLS quando aplicável).
- `user_roles` não deve permitir que usuário comum se promova a mestre/Super Admin.
- Dados de alunos menores e responsáveis devem ser mínimos, com acesso limitado e histórico de ações relevantes.
- Pagamentos devem usar um provedor; não armazenar número completo de cartão/CVV.

## 5. Configurações futuras por academia

### Identidade e operação
- Nome público, logotipo, cores e dados de contato.
- Fuso horário, idioma, moeda e formato de data.
- Unidades/filiais e regras de compartilhamento entre elas.
- Termos, política de privacidade e modelos de consentimento.

### Modalidades e currículo
- Uma ou várias modalidades (ex.: Hapkido, Karate, BJJ, Taekwondo), com nomenclatura própria.
- Sequência de faixas/graus, cores, requisitos, idade mínima se aplicável, tempo mínimo e número de aulas; todos opcionais e configuráveis.
- Técnicas agrupadas por modalidade, faixa, categoria e mídia.
- Exames, critérios de elegibilidade, aprovador e histórico imutável de graduações.
- Configuração não deve assumir que todas as artes marciais usam o mesmo sistema de faixas.

### Pessoas e permissões
- Papéis padrão e permissões granulares por módulo/ação.
- Instrutores vinculados a turmas/modalidades específicas.
- Responsável ligado a um ou mais alunos, com escopo de leitura definido.
- Aprovação de cadastro e desativação/revogação de acesso.

### Aulas e presença
- Turmas, locais, instrutores, capacidade, recorrência e lista de espera.
- Métodos de check-in configuráveis; evitar expor dados de outros alunos no quiosque.
- Política para presença duplicada, atraso, reposição e cancelamento.

### Financeiro e comunicação
- Planos de matrícula, vencimento, descontos e política de atraso.
- Estados financeiros explícitos e histórico de alterações.
- Preferências de comunicação e opt-in para canais externos.
- Modelos de mensagem, lembretes e limites para evitar spam.

### Personalização do produto SaaS
- Módulos habilitados por plano, limites e período de teste.
- Importação/exportação, retenção e exclusão de dados.
- Idioma e identidade visual por tenant.
- Cobrança do SaaS separada das mensalidades pagas pelos alunos à academia.

## 6. Matriz de prioridades

### P0 — Segurança e integridade antes de ampliar recursos
1. Catalogar políticas RLS por tabela/operação e revisar políticas antigas permissivas.
2. Rever funções com `service_role`, `SECURITY DEFINER`, `EXECUTE`, triggers e realtime.
3. Eliminar enumeração/exposição desnecessária de e-mails em fluxos de login.
4. Proteger endpoints públicos de cadastro com validação, limites e mecanismos antiabuso adequados.
5. Executar build, lint e typecheck; criar testes negativos de autorização.
6. Testar duas academias fictícias com Mestre, administrador, instrutor, aluno, responsável e Super Admin.

### P1 — Núcleo da academia
1. Aluno e família/responsável.
2. Turmas e agenda.
3. Presença/check-in e relatórios.
4. Modalidades, currículo, exames e histórico de graduação.
5. Financeiro básico e histórico de mudanças.
6. Notificações e avisos.

### P2 — Eficiência e retenção
1. Painel de tarefas por papel.
2. Alertas de faltas e elegibilidade para exame.
3. CRM de interessados e aula experimental.
4. Portal do aluno/responsável.
5. Importação/exportação e relatórios.

### P3 — Expansão competitiva
1. Automações configuráveis.
2. Mensagens multicanal, após avaliar custos e consentimento.
3. POS/estoque, eventos avançados e agendamento de atendimentos.
4. Multiunidade, planos SaaS e cobrança da plataforma.
5. PWA/app nativo decidido por necessidade comprovada.

## 7. Critérios de aceite antes de chamar uma função de pronta

- Permissões conferidas no servidor e no banco.
- Nenhuma leitura ou escrita cruzada entre academias em testes negativos.
- Estados de carregamento, vazio e erro visíveis; falha não aparece como lista vazia normal.
- Validação de entradas e prevenção de duplicação/conflitos.
- Testes de regressão das telas e funções relacionadas.
- Uso aceitável em Android real, incluindo navegação, teclado e telas pequenas.
- Migração de banco revisada e testada fora de produção; backup e reversão documentados.

## 8. Próxima alteração recomendada

Não adicionar ainda CRM, pagamentos integrados ou automações. O próximo trabalho deve gerar um inventário exato de políticas por tabela e operação, identificar duplicatas/escopos amplos e preparar uma migração SQL proposta sem executá-la em produção. Depois: build/lint/typecheck e testes de isolamento. Só então começar o primeiro módulo funcional com mudanças pequenas e reversíveis.
