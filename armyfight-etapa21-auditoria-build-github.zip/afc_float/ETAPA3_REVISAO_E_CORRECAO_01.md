# Etapa 3 — Revisão de autenticação e primeira correção

## Escopo
Revisão estática de `src/integrations/supabase/auth-middleware.ts`, `client.server.ts`, `auth-attacher.ts`, `src/lib/super.functions.ts`, `academias.functions.ts`, `alunos.functions.ts` e das migrations relacionadas a criação de perfis e papéis. Não houve acesso ao banco real nem teste de produção.

## O que a revisão confirma no código

- `requireSupabaseAuth` exige `Authorization: Bearer`, verifica o token com `supabase.auth.getClaims(token)` e entrega `userId`/claims e um cliente Supabase autenticado ao handler. Isso é um controle positivo no middleware.
- `client.server.ts` mantém a chave `SUPABASE_SERVICE_ROLE_KEY` no lado servidor, com criação preguiçosa do cliente administrativo. O padrão depende de esses imports permanecerem exclusivos do servidor.
- `definirSenhaAluno` e `rejeitarCadastro` usam o middleware, validam o papel de Mestre/Super e verificam se o aluno pertence à academia do ator antes de usar o cliente administrativo.
- `solicitarAcademia`, `solicitarCadastro`, `resolverLoginAcademia` e `resolveSuperEmail` são fluxos públicos sem o middleware de autenticação. Alguns podem ser intencionalmente públicos, mas precisam de proteção antiabuso e revisão de enumeração/exposição de identificadores.
- `resolveSuperEmail` retorna o e-mail real da conta Super correspondente ao nome/usuário informado. Isso pode permitir descoberta do identificador de login; a correção completa exige redesenhar o fluxo de login, pois a tela atual depende desse retorno. Não alterado nesta etapa para evitar quebrar autenticação.
- `resolverLoginAcademia` consulta perfil por nome normalizado e devolve `profiles.email` quando encontrado. O fluxo deve ser avaliado junto ao método de login e aos dados legados antes de remover esse comportamento.
- As migrations incluem funções `SECURITY DEFINER` e políticas RLS. A revisão do arquivo não prova quais migrations foram aplicadas ao banco atual.

## Correção 01 aplicada

Arquivo: `src/lib/academias.functions.ts`, função `solicitarAcademia`.

Antes, a consulta para verificar se o slug já existia ignorava erros de consulta. Uma falha de banco podia ser interpretada como “slug disponível”, levando a uma tentativa de inserção com um identificador possivelmente duplicado e a um erro pouco claro.

Agora:
1. A consulta verifica explicitamente `lookupError`.
2. Em caso de falha, o servidor registra o erro técnico e retorna uma mensagem genérica ao usuário.
3. A seleção do candidato cobre até 50 opções e falha explicitamente se nenhuma estiver disponível.

### Limites da correção
- Não elimina condição de corrida entre a consulta e o `INSERT`; a restrição `UNIQUE` do banco continua sendo a proteção final. O tratamento específico de conflito deve ser confirmado com o esquema real.
- Não adiciona rate limit/CAPTCHA, que requer decisão de arquitetura e/ou armazenamento compartilhado.
- Não foi executado build, lint ou teste de integração nesta etapa. A correção ainda precisa ser validada no ambiente de desenvolvimento.
- Nenhuma migration foi executada e nenhum banco foi alterado.

## Testes de aceitação para a correção 01

1. Nome de academia sem conflito: cria solicitação e escolhe o slug base.
2. Slug já usado: escolhe o próximo candidato disponível.
3. Falha na consulta de disponibilidade: não tenta inserir a academia e mostra mensagem genérica.
4. Todos os 50 candidatos ocupados: não tenta inserir e pede outro nome.
5. Duas solicitações simultâneas com o mesmo nome: a restrição única do banco deve impedir duplicação; o tratamento da violação de unicidade ainda precisa ser validado.

## Próximas correções recomendadas

1. Revisar e redesenhar a resolução de usuário Super sem devolver e-mail real antes da autenticação.
2. Definir mitigação antiabuso para os endpoints públicos de cadastro e login.
3. Confirmar restrições `UNIQUE`, índices e trigger `handle_new_user` no esquema das migrations.
4. Rodar build/lint/TypeScript e testes em ambiente não produtivo.
5. Testar isolamento entre duas academias com contas e papéis separados.
