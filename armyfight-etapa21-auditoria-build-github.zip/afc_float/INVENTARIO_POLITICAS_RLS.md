# Etapa 1 — Inventário estático de políticas RLS

**Status:** análise do código-fonte das migrations; não é uma leitura do banco Supabase em produção.

## Objetivo
Mapear as políticas de Row-Level Security (RLS) e os pontos que precisam de validação antes de qualquer mudança. Nenhuma migration foi executada e nenhuma política foi alterada nesta etapa.

## Achados principais

1. A migration `20260724010333_...sql` cria políticas iniciais chamadas `Mestre manages ...` para tabelas como `techniques`, `mensalidades`, `presencas`, `exames` e `app_settings`.
2. A migration `20260802000628_...sql` tenta substituir várias políticas antigas por versões que verificam `academia_id = user_academia(auth.uid())` e incluem exceção para Super Admin.
3. A migration `20260901234553_...sql` substitui políticas de `user_roles` por versões com escopo de academia e bloqueio explícito de cargo `super` para Mestres.
4. PostgreSQL combina políticas permissivas aplicáveis com **OR**. Portanto, uma política antiga e ampla que permaneça ativa pode ampliar o acesso, mesmo quando existe uma política nova mais restritiva. Fonte: documentação oficial do PostgreSQL, https://www.postgresql.org/docs/current/ddl-rowsecurity.html.
5. O repositório contém apenas o histórico de migrations. Não confirma quais migrations foram aplicadas no projeto Supabase real, se houve mudanças manuais, nem as permissões efetivas do banco.

## Inventário das áreas vistas no código

| Tabela/área | Evidência no histórico | Revisão necessária |
|---|---|---|
| `profiles` | políticas próprias e políticas de Mestre; migration posterior cria leitura/alteração/exclusão por academia | Confirmar políticas antigas removidas e validar campos privilegiados e operações por papel |
| `user_roles` | políticas iniciais e duas migrations posteriores de substituição | Confirmar somente as políticas finais esperadas; testar que Mestre não concede cargo `super` nem mexe em outra academia |
| `techniques` | leitura aprovada e gestão de Mestre; versão posterior passa a incluir academia | Confirmar políticas antigas removidas e testar leitura por aluno/instrutor e escrita por Mestre |
| `mensalidades`, `presencas`, `exames` | aluno lê registros próprios; Mestre gerencia; migration posterior recria gestão por academia | Conferir coluna `academia_id`, política do aluno para cada operação e isolamento entre academias |
| `graduacoes`, `objetivos`, `certificados`, `notificacoes`, `conquistas` | leitura própria e gestão de Mestre; versões posteriores com escopo de academia | Conferir políticas anteriores, acesso do aluno e operações permitidas para cada papel |
| `app_settings`, `avisos`, `destaques` | políticas iniciais de leitura autenticada e gestão; depois substituídas por escopo de academia | Confirmar ausência de política global permissiva residual; decidir quais dados podem ser públicos |
| `admin_permissoes` | políticas de Mestre; depois gestão por academia e leitura das próprias permissões | Testar isolamento e impedir elevação de privilégios |
| `academias` | leitura pública de academias ativas, leitura autenticada, gestão Super e edição pelo Mestre | Revisar cuidadosamente quais campos são públicos e se update do Mestre preserva o mesmo `id` |
| `academia_faixas` | leitura e gestão por academia/Super | Confirmar tabela e relação de tenant; testar isolamento |
| `comunicados_plataforma` | leitura de comunicados ativos e gestão Super | Confirmar que usuários comuns não podem alterar comunicados |
| `suporte_tickets` | criar/ler próprios tickets e responder como Super | Validar leitura/alteração pelo autor e escopo por academia |

## Funções `SECURITY DEFINER`
As migrations também declaram funções `SECURITY DEFINER`, inclusive helpers de autorização e triggers. Esse atributo não é automaticamente uma falha, mas exige revisar: `search_path` fixo, privilégios `EXECUTE`, validação do chamador, tabelas acessadas e se alguma função expõe dados ou permite alterações privilegiadas. Não foi feita nesta etapa uma auditoria completa de cada corpo de função.

## Plano de testes antes de mudar políticas

- [ ] Obter o esquema/políticas efetivas do ambiente Supabase de desenvolvimento, sem compartilhar chaves ou segredos.
- [ ] Criar ou usar duas academias de teste, cada uma com Mestre, administrador, instrutor e aluno fictícios.
- [ ] Testar `SELECT`, `INSERT`, `UPDATE` e `DELETE` por tabela e papel, conforme esperado.
- [ ] Tentar ler e alterar registros da outra academia; o resultado esperado é bloqueio.
- [ ] Tentar aluno alterar o próprio papel, academia, status, faixa ou outros campos privilegiados; deve ser bloqueado.
- [ ] Testar acesso anônimo às tabelas públicas e confirmar que apenas dados explicitamente públicos ficam visíveis.
- [ ] Executar testes em ambiente não produtivo e guardar backup/rollback antes de qualquer migration.

## Decisão desta etapa
**Não criar uma migration corretiva ainda.** Primeiro precisamos comparar este inventário com o estado real do banco e ler as migrations completas e funções relevantes. Remover ou recriar políticas com base apenas no histórico pode quebrar o acesso legítimo ou deixar uma política antiga ativa.

## Referência técnica
- PostgreSQL — Row Security Policies: https://www.postgresql.org/docs/current/ddl-rowsecurity.html
- PostgreSQL — `CREATE POLICY`: https://www.postgresql.org/docs/16/sql-createpolicy.html
