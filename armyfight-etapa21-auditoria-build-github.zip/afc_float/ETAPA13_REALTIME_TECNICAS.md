# Etapa 13 — Consistência de técnicas em tempo real

## Alterações
- A assinatura de técnicas agora é recriada quando muda o usuário ou a academia ativa.
- O canal tem nome exclusivo por academia/usuário, reduzindo colisões entre sessões.
- Eventos INSERT, UPDATE e DELETE disparam uma nova leitura ordenada pelo banco (`posicao ASC`), evitando que técnicas novas/editadas fiquem fora de ordem na lista local.
- Ao trocar o escopo de academia ou usuário, a lista local é limpa enquanto os dados corretos são carregados, evitando mostrar temporariamente técnicas da academia anterior.
- Se a consulta falhar, o código mantém o estado atual em vez de substituir os dados por uma lista vazia silenciosamente.

## Limites de validação
- Não foi possível validar conexão Supabase real com duas contas/dispositivos nesta etapa.
- O build/lint não foi executado porque as dependências ainda não estão instaladas neste ambiente.
- Realtime depende de a tabela `public.techniques` estar na publicação `supabase_realtime`, da configuração de permissões/RLS e de credenciais válidas no ambiente publicado.
- A alteração atual resolve a consistência/ordenação no cliente; não substitui os testes reais de autorização e isolamento multiacademia.

## Teste manual obrigatório
1. Entrar como mestre e aluno da mesma academia em duas sessões separadas.
2. Adicionar técnica e confirmar que aparece na sessão do aluno sem recarregar.
3. Editar título/descrição/vídeo/imagem; confirmar atualização nos dois lados.
4. Mover técnica para cima/baixo; confirmar a ordem em ambas as sessões.
5. Excluir técnica; confirmar remoção em ambas.
6. Repetir com outra academia e confirmar que nenhuma alteração cruza os limites entre academias.
7. Desconectar/reconectar a internet e repetir para observar a reconexão do canal.
