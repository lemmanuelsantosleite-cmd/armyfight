# Martial Hub / Army Fight Club — Matriz inicial de auditoria

**Status:** análise estática do código; não substitui testes de execução, banco ou contas reais.

Legenda: **Visível no código** = há evidência na implementação; **Verificar** = precisa de teste/inspeção adicional; **Risco** = ponto que merece correção antes de ampliar o sistema.

| Área/rota | Evidência observada | Permissão/isolamento | Próxima verificação |
|---|---|---|---|
| `/` | Redireciona para `/academia` no modo academia única | — | Confirmar se esse modo é intencional e não conflita com a futura entrada multiacademia |
| `/entrar` | Seleção de academias temporariamente desativada e redirecionada | — | Planejar reativação só após validar login e seleção segura do tenant |
| `/criar-academia` | Cadastro público desativado na rota; existe função server `solicitarAcademia` | Função usa cliente administrativo Supabase | **Risco:** revisar abuso/rate limit, validação de duplicidade e fluxo de aprovação antes de reativar |
| `/academia` | Conteúdo de técnicas e faixas; redireciona usuários não mestres para `/aluno` | Parte da lógica parece depender de estado/perfil no cliente | Verificar origem dos dados, controles de acesso no banco e persistência de configurações |
| `/belt/$beltId` | Conteúdo por faixa, bloqueio por graduação e botão de adicionar técnica | Bloqueio visível na interface não é suficiente como controle de segurança | Testar acesso direto à rota e permissões das operações de escrita |
| `/admin` | Consulta profiles, mensalidades, presenças e exames filtrando por `tenantId()`; redireciona quem não é mestre | Usa helper de tenant no cliente | **Risco:** tenant client-side não é fronteira de segurança; confirmar RLS em todas as tabelas e operações |
| `/aluno` | Consulta mensalidades, presenças, exames, graduações, objetivos, certificados e notificações por `aluno_id`; assina atualizações em tempo real | Filtros por aluno no cliente | Testar RLS para impedir leitura de dados de outro aluno e eventos em tempo real indevidos |
| `/hub` | Painel global consulta academias, perfis, suporte e comunicados; criação de academia pela interface | Deve ser exclusivo do Super Admin | Confirmar que cada consulta/escrita é protegida no banco ou server-side, não só por navegação |
| `/super` | Login e verificação de cargo `super`; usa `resolveSuperEmail` | A função de resolução consulta usuários via service role | **Risco:** função pública pode revelar e-mail interno de conta Super; revisar o fluxo de login sem expor e-mail |
| `solicitarCadastro` | Cria usuário por cliente administrativo a partir de nome e academia | Endpoint público com acesso privilegiado ao Supabase | **Risco:** rate limiting/antiabuso e validação do fluxo de cadastro pendente |
| `definirSenhaAluno` / `rejeitarCadastro` | Funções server incluem validação de cargo e pertencimento à academia na cópia auditada | Verificação server-side presente no código | Criar testes negativos com mestre de outra academia, aluno comum e Super Admin |
| `getHubPortalData` | Verifica sessão/cargo Super antes de consultas privilegiadas na cópia auditada | Validação server-side presente no código | Testar chamada direta sem sessão, com usuário comum e com erro de consulta |
| `tenant.ts` | Mantém `activeAcademiaId` em variável de módulo e `tenantId()` usa UUID sentinela quando vazio | Escopo depende de estado client-side | Não confiar nesse helper para segurança; verificar inicialização, isolamento entre sessões e RLS |
| Migrações/RLS | Migrações ativam RLS em tabelas e criam políticas | Cobertura e consistência ainda não foram comprovadas | Catalogar cada tabela/política, revisar funções `SECURITY DEFINER` e testar isolamento entre duas academias |

## Sequência de atualização segura

1. **Sem novos recursos por enquanto:** mapear tabelas, políticas e funções que fazem escrita.
2. Testar build, lint e TypeScript após instalar dependências em ambiente controlado.
3. Testar duas academias fictícias e contas de mestre, admin limitado, aluno e Super Admin.
4. Corrigir primeiro falhas reproduzíveis de autorização e dados; uma alteração por vez.
5. Só depois iniciar o fluxo funcional de aluno: cadastro → turma → presença → técnicas → exame → graduação → histórico.

## Limitações desta rodada

- Não houve execução do aplicativo, build, lint, typecheck ou testes de integração.
- Não houve conexão com banco de produção nem uso de credenciais reais.
- A presença de uma tela, tabela ou política não prova que a funcionalidade esteja completa ou segura.
- Nenhuma nova migração de banco foi aplicada.
