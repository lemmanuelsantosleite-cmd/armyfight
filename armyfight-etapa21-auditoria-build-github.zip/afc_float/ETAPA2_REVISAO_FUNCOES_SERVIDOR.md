# Etapa 2 — Revisão estática das funções de servidor

**Base analisada:** `armyfight-etapa1-inventario-rls.zip` (cópia de auditoria).  
**Escopo:** leitura estática de `src/lib/academias.functions.ts`, `alunos.functions.ts`, `hub.functions.ts` e `super.functions.ts`.  
**Limitação:** não foi executado build, teste automatizado, autenticação real nem consulta ao banco Supabase. Os itens abaixo são achados de código e hipóteses de risco a validar, não confirmação de exploração em produção.

## Achados prioritários

### F-01 — Endpoints privilegiados sem autenticação explícita e sem controles antiabuso visíveis
**Arquivos:** `src/lib/academias.functions.ts` (`solicitarAcademia`); `src/lib/alunos.functions.ts` (`solicitarCadastro`, `resolverLoginAcademia`); `src/lib/super.functions.ts` (`resolveSuperEmail`).

- Essas funções não declaram `requireSupabaseAuth` middleware.
- `solicitarAcademia` e `solicitarCadastro` usam `supabaseAdmin` para criar registros/usuários.
- `resolverLoginAcademia` e `resolveSuperEmail` consultam dados usando cliente administrativo e retornam um e-mail derivado/encontrado.
- Não foi encontrado, nesses arquivos, rate limit, CAPTCHA ou outro controle antiabuso explícito.

**Risco:** abuso automatizado, criação em massa de solicitações/contas e enumeração de identidade/login. A validação Zod limita formato e tamanho, mas não limita frequência. O impacto real depende de regras complementares, middleware global, infraestrutura e configuração do projeto, ainda não verificadas.

**Próxima ação recomendada:** definir política para cada endpoint público. Aplicar limitação de frequência no servidor/edge, respostas que minimizem enumeração e monitoramento. Não adicionar autenticação a fluxos que precisam ser públicos sem primeiro decidir o fluxo de produto.

### F-02 — `resolveSuperEmail` faz busca ampla por contas privilegiadas
**Arquivo:** `src/lib/super.functions.ts`.

A função lista todos os usuários de autenticação em páginas de até 200, até 20 páginas, compara e-mail, parte local e metadado `nome`, e retorna o e-mail da conta super correspondente.

**Risco:** endpoint público pode permitir tentativas repetidas para descobrir a identidade/e-mail da conta super; também pode gerar consultas administrativas custosas sob abuso. Não retorna senha nem token, mas o e-mail é informação sensível para o fluxo de autenticação.

**Próxima ação recomendada:** evitar resolução de conta privilegiada por nome em endpoint público. Preferir identificador fixo de login não enumerável ou login normal por e-mail, com mensagens uniformes, rate limit e monitoramento. Confirmar dependências de UI antes de alterar.

### F-03 — `solicitarCadastro` cria usuário Auth, mas o trecho não mostra a criação correspondente de perfil/papel
**Arquivo:** `src/lib/alunos.functions.ts`.

O endpoint valida academia e nome duplicado em `profiles`, depois chama `supabaseAdmin.auth.admin.createUser`. Nesse arquivo não aparece inserção em `profiles` ou `user_roles` nessa função.

**Risco/questão de integridade:** pode existir trigger ou outro mecanismo de sincronização no banco; sem revisar todas as migrations e o estado real do banco, não se pode concluir que o perfil fica ausente. Se não existir mecanismo, podem surgir contas Auth sem perfil associado.

**Próxima ação recomendada:** localizar triggers/functions de criação automática de perfil nas migrations e confirmar fluxo completo antes de modificar.

### F-04 — Mensagens de erro internas podem ser devolvidas ao chamador
**Arquivos:** `academias.functions.ts`, `alunos.functions.ts`, `hub.functions.ts`, `super.functions.ts`.

Alguns caminhos lançam diretamente `error.message` ou propagam erros do SDK. A exposição depende de como o TanStack Start serializa os erros e de como a interface os exibe.

**Risco:** revelar detalhes internos de esquema, Auth ou banco; mensagens podem também ser pouco compreensíveis para usuários.

**Próxima ação recomendada:** padronizar mensagens públicas e registrar detalhes apenas no servidor, sem logar senhas, tokens ou segredos.

### F-05 — Geração de slug de academia sujeita a concorrência
**Arquivo:** `src/lib/academias.functions.ts`.

`solicitarAcademia` consulta slugs sequencialmente até encontrar um aparentemente livre e então insere o registro. Duas solicitações simultâneas podem escolher o mesmo slug se a unicidade não for garantida no banco e o erro de conflito não for tratado com nova tentativa.

**Próxima ação recomendada:** confirmar constraint `UNIQUE` na coluna `slug`; se existir, tratar conflito e repetir a geração com limite. Não presumir ausência da constraint sem examinar migrations/banco.

## Pontos já protegidos visivelmente neste recorte

- `definirSenhaAluno` e `rejeitarCadastro` declaram `requireSupabaseAuth`.
- Ambas chamam `assertMestre` e `assertAlunoDaAcademia` antes de usar o cliente administrativo para alterar/deletar conta.
- `getHubPortalData` exige sessão e verifica a função `super` antes das consultas administrativas.
- As entradas usam validação Zod com limites para campos apresentados.

Isso não substitui testes e não prova que todos os papéis/escopos estão corretos; por exemplo, é necessário verificar a definição de `requireSupabaseAuth`, a fonte confiável de `academia_id`, as políticas RLS e os triggers.

## Plano de teste para a próxima rodada

1. Revisar `auth-middleware` e `client.server.ts`; confirmar que o cliente administrativo nunca chega ao bundle do navegador e que a chave secreta só existe no servidor.
2. Procurar nas migrations: `CREATE TRIGGER`, funções que criam `profiles`/`user_roles`, constraints `UNIQUE` em `academias.slug`, `SECURITY DEFINER` e grants de execução.
3. Mapear chamadas de UI para `resolveSuperEmail`, `resolverLoginAcademia`, `solicitarCadastro` e `solicitarAcademia` antes de alterar seus contratos.
4. Preparar correção pequena para o primeiro risco confirmado, com teste automatizado ou procedimento reproduzível.
5. Executar build/lint/TypeScript quando as dependências estiverem disponíveis; ainda não há resultado de build nesta etapa.

## Estado

- [x] Revisão estática inicial das quatro funções de servidor.
- [x] Registro dos riscos e perguntas pendentes.
- [ ] Verificação de middleware, cliente admin e migrations relacionadas.
- [ ] Testes automatizados e build.
- [ ] Correções de código — ainda não aplicadas nesta etapa.
