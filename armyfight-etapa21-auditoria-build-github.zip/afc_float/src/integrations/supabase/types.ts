export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      academia_faixas: {
        Row: {
          academia_id: string
          codigo: string
          cor_texto: string
          cor1: string
          cor2: string
          created_at: string
          dan: number
          id: string
          nome: string
          posicao: number
          requisitos: string
          updated_at: string
        }
        Insert: {
          academia_id: string
          codigo: string
          cor_texto?: string
          cor1?: string
          cor2?: string
          created_at?: string
          dan?: number
          id?: string
          nome: string
          posicao?: number
          requisitos?: string
          updated_at?: string
        }
        Update: {
          academia_id?: string
          codigo?: string
          cor_texto?: string
          cor1?: string
          cor2?: string
          created_at?: string
          dan?: number
          id?: string
          nome?: string
          posicao?: number
          requisitos?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "academia_faixas_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      academias: {
        Row: {
          assinatura_url: string
          banner_url: string
          cor_primaria: string
          cor_secundaria: string
          created_at: string
          email: string
          endereco: string
          horarios: string
          id: string
          instagram: string
          logo_url: string
          max_alunos: number
          modalidade: string
          nome: string
          observacao: string
          plano: Database["public"]["Enums"]["plano_tipo"]
          slug: string
          status: Database["public"]["Enums"]["academia_status"]
          telefone: string
          updated_at: string
          whatsapp: string
        }
        Insert: {
          assinatura_url?: string
          banner_url?: string
          cor_primaria?: string
          cor_secundaria?: string
          created_at?: string
          email?: string
          endereco?: string
          horarios?: string
          id?: string
          instagram?: string
          logo_url?: string
          max_alunos?: number
          modalidade?: string
          nome: string
          observacao?: string
          plano?: Database["public"]["Enums"]["plano_tipo"]
          slug: string
          status?: Database["public"]["Enums"]["academia_status"]
          telefone?: string
          updated_at?: string
          whatsapp?: string
        }
        Update: {
          assinatura_url?: string
          banner_url?: string
          cor_primaria?: string
          cor_secundaria?: string
          created_at?: string
          email?: string
          endereco?: string
          horarios?: string
          id?: string
          instagram?: string
          logo_url?: string
          max_alunos?: number
          modalidade?: string
          nome?: string
          observacao?: string
          plano?: Database["public"]["Enums"]["plano_tipo"]
          slug?: string
          status?: Database["public"]["Enums"]["academia_status"]
          telefone?: string
          updated_at?: string
          whatsapp?: string
        }
        Relationships: []
      }
      admin_permissoes: {
        Row: {
          academia_id: string | null
          aprovar_alunos: boolean
          created_at: string
          criar_exame: boolean
          editar_exame: boolean
          editar_tecnicas: boolean
          emitir_certificado: boolean
          lancar_mensalidade: boolean
          marcar_presenca: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          academia_id?: string | null
          aprovar_alunos?: boolean
          created_at?: string
          criar_exame?: boolean
          editar_exame?: boolean
          editar_tecnicas?: boolean
          emitir_certificado?: boolean
          lancar_mensalidade?: boolean
          marcar_presenca?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          academia_id?: string | null
          aprovar_alunos?: boolean
          created_at?: string
          criar_exame?: boolean
          editar_exame?: boolean
          editar_tecnicas?: boolean
          emitir_certificado?: boolean
          lancar_mensalidade?: boolean
          marcar_presenca?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_permissoes_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          academia_id: string
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          academia_id: string
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          academia_id?: string
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: [
          {
            foreignKeyName: "app_settings_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      avisos: {
        Row: {
          academia_id: string | null
          autor_nome: string
          created_at: string
          fixado: boolean
          id: string
          mensagem: string
          tipo: string
          titulo: string
          updated_at: string
        }
        Insert: {
          academia_id?: string | null
          autor_nome?: string
          created_at?: string
          fixado?: boolean
          id?: string
          mensagem?: string
          tipo?: string
          titulo: string
          updated_at?: string
        }
        Update: {
          academia_id?: string | null
          autor_nome?: string
          created_at?: string
          fixado?: boolean
          id?: string
          mensagem?: string
          tipo?: string
          titulo?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "avisos_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      certificados: {
        Row: {
          academia_id: string | null
          aluno_id: string
          arquivo_url: string
          created_at: string
          data_emissao: string
          faixa_id: string
          id: string
          mestre_nome: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          arquivo_url?: string
          created_at?: string
          data_emissao?: string
          faixa_id: string
          id?: string
          mestre_nome?: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          arquivo_url?: string
          created_at?: string
          data_emissao?: string
          faixa_id?: string
          id?: string
          mestre_nome?: string
        }
        Relationships: [
          {
            foreignKeyName: "certificados_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      comunicados_plataforma: {
        Row: {
          ativo: boolean
          created_at: string
          id: string
          mensagem: string
          titulo: string
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          id?: string
          mensagem?: string
          titulo: string
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          id?: string
          mensagem?: string
          titulo?: string
          updated_at?: string
        }
        Relationships: []
      }
      conquistas: {
        Row: {
          academia_id: string | null
          aluno_id: string
          created_at: string
          data: string
          descricao: string | null
          icone: string
          id: string
          titulo: string
          updated_at: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          created_at?: string
          data?: string
          descricao?: string | null
          icone?: string
          id?: string
          titulo: string
          updated_at?: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          created_at?: string
          data?: string
          descricao?: string | null
          icone?: string
          id?: string
          titulo?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conquistas_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conquistas_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      destaques: {
        Row: {
          academia_id: string | null
          aluno_id: string
          aluno_nome: string
          ativo: boolean
          created_at: string
          id: string
          mes: string
          motivo: string
          updated_at: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          aluno_nome?: string
          ativo?: boolean
          created_at?: string
          id?: string
          mes?: string
          motivo?: string
          updated_at?: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          aluno_nome?: string
          ativo?: boolean
          created_at?: string
          id?: string
          mes?: string
          motivo?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "destaques_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      exames: {
        Row: {
          academia_id: string | null
          aluno_id: string
          comentario: string | null
          created_at: string
          data_exame: string
          faixa_atual: string
          faixa_proxima: string
          id: string
          nota: number | null
          observacao: string | null
          status: Database["public"]["Enums"]["exame_status"]
          updated_at: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          comentario?: string | null
          created_at?: string
          data_exame: string
          faixa_atual: string
          faixa_proxima: string
          id?: string
          nota?: number | null
          observacao?: string | null
          status?: Database["public"]["Enums"]["exame_status"]
          updated_at?: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          comentario?: string | null
          created_at?: string
          data_exame?: string
          faixa_atual?: string
          faixa_proxima?: string
          id?: string
          nota?: number | null
          observacao?: string | null
          status?: Database["public"]["Enums"]["exame_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "exames_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exames_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      graduacoes: {
        Row: {
          academia_id: string | null
          aluno_id: string
          created_at: string
          data: string
          faixa_id: string
          id: string
          observacao: string | null
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          created_at?: string
          data?: string
          faixa_id: string
          id?: string
          observacao?: string | null
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          created_at?: string
          data?: string
          faixa_id?: string
          id?: string
          observacao?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "graduacoes_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      mensalidades: {
        Row: {
          academia_id: string | null
          aluno_id: string
          created_at: string
          id: string
          observacao: string | null
          pago_em: string | null
          status: Database["public"]["Enums"]["mensalidade_status"]
          updated_at: string
          valor: number
          vencimento: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          created_at?: string
          id?: string
          observacao?: string | null
          pago_em?: string | null
          status?: Database["public"]["Enums"]["mensalidade_status"]
          updated_at?: string
          valor: number
          vencimento: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          created_at?: string
          id?: string
          observacao?: string | null
          pago_em?: string | null
          status?: Database["public"]["Enums"]["mensalidade_status"]
          updated_at?: string
          valor?: number
          vencimento?: string
        }
        Relationships: [
          {
            foreignKeyName: "mensalidades_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mensalidades_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notificacoes: {
        Row: {
          academia_id: string | null
          aluno_id: string
          created_at: string
          id: string
          lida: boolean
          mensagem: string
          titulo: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          created_at?: string
          id?: string
          lida?: boolean
          mensagem?: string
          titulo: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          created_at?: string
          id?: string
          lida?: boolean
          mensagem?: string
          titulo?: string
        }
        Relationships: [
          {
            foreignKeyName: "notificacoes_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      objetivos: {
        Row: {
          academia_id: string | null
          aluno_id: string
          concluido: boolean
          created_at: string
          id: string
          posicao: number
          texto: string
          updated_at: string
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          concluido?: boolean
          created_at?: string
          id?: string
          posicao?: number
          texto: string
          updated_at?: string
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          concluido?: boolean
          created_at?: string
          id?: string
          posicao?: number
          texto?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "objetivos_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      presencas: {
        Row: {
          academia_id: string | null
          aluno_id: string
          created_at: string
          data: string
          id: string
          observacao: string | null
          presente: boolean
          tipo_aula: string | null
          turma: Database["public"]["Enums"]["turma_tipo"] | null
        }
        Insert: {
          academia_id?: string | null
          aluno_id: string
          created_at?: string
          data: string
          id?: string
          observacao?: string | null
          presente?: boolean
          tipo_aula?: string | null
          turma?: Database["public"]["Enums"]["turma_tipo"] | null
        }
        Update: {
          academia_id?: string | null
          aluno_id?: string
          created_at?: string
          data?: string
          id?: string
          observacao?: string | null
          presente?: boolean
          tipo_aula?: string | null
          turma?: Database["public"]["Enums"]["turma_tipo"] | null
        }
        Relationships: [
          {
            foreignKeyName: "presencas_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "presencas_aluno_id_fkey"
            columns: ["aluno_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          academia_id: string | null
          bloqueado_inadimplencia: boolean
          created_at: string
          data_matricula: string
          data_nascimento: string | null
          email: string
          faixa_id: string
          foto_url: string | null
          id: string
          nome: string
          nome_slug: string | null
          status: Database["public"]["Enums"]["aluno_status"]
          telefone: string | null
          turma: Database["public"]["Enums"]["turma_tipo"]
          updated_at: string
        }
        Insert: {
          academia_id?: string | null
          bloqueado_inadimplencia?: boolean
          created_at?: string
          data_matricula?: string
          data_nascimento?: string | null
          email: string
          faixa_id?: string
          foto_url?: string | null
          id: string
          nome: string
          nome_slug?: string | null
          status?: Database["public"]["Enums"]["aluno_status"]
          telefone?: string | null
          turma?: Database["public"]["Enums"]["turma_tipo"]
          updated_at?: string
        }
        Update: {
          academia_id?: string | null
          bloqueado_inadimplencia?: boolean
          created_at?: string
          data_matricula?: string
          data_nascimento?: string | null
          email?: string
          faixa_id?: string
          foto_url?: string | null
          id?: string
          nome?: string
          nome_slug?: string | null
          status?: Database["public"]["Enums"]["aluno_status"]
          telefone?: string | null
          turma?: Database["public"]["Enums"]["turma_tipo"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      suporte_tickets: {
        Row: {
          academia_id: string | null
          assunto: string
          autor_nome: string
          created_at: string
          id: string
          mensagem: string
          resposta: string
          status: string
          tipo: string
          updated_at: string
          user_id: string
        }
        Insert: {
          academia_id?: string | null
          assunto: string
          autor_nome?: string
          created_at?: string
          id?: string
          mensagem?: string
          resposta?: string
          status?: string
          tipo?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          academia_id?: string | null
          assunto?: string
          autor_nome?: string
          created_at?: string
          id?: string
          mensagem?: string
          resposta?: string
          status?: string
          tipo?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "suporte_tickets_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      techniques: {
        Row: {
          academia_id: string | null
          autor_nome: string
          belt_id: string
          categoria: Database["public"]["Enums"]["tecnica_categoria"]
          created_at: string
          descricao: string
          id: string
          imagem_url: string
          posicao: number
          titulo: string
          updated_at: string
          video_url: string
        }
        Insert: {
          academia_id?: string | null
          autor_nome?: string
          belt_id: string
          categoria: Database["public"]["Enums"]["tecnica_categoria"]
          created_at?: string
          descricao?: string
          id?: string
          imagem_url?: string
          posicao?: number
          titulo: string
          updated_at?: string
          video_url?: string
        }
        Update: {
          academia_id?: string | null
          autor_nome?: string
          belt_id?: string
          categoria?: Database["public"]["Enums"]["tecnica_categoria"]
          created_at?: string
          descricao?: string
          id?: string
          imagem_url?: string
          posicao?: number
          titulo?: string
          updated_at?: string
          video_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "techniques_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          academia_id: string | null
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          academia_id?: string | null
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          academia_id?: string | null
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_academia_id_fkey"
            columns: ["academia_id"]
            isOneToOne: false
            referencedRelation: "academias"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      afc_slug: { Args: { _nome: string }; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_mestre: { Args: { _user_id: string }; Returns: boolean }
      is_super: { Args: { _user_id: string }; Returns: boolean }
      unaccent_fallback: { Args: { _t: string }; Returns: string }
      user_academia: { Args: { _user_id: string }; Returns: string }
    }
    Enums: {
      academia_status: "pendente" | "teste" | "ativa" | "suspensa" | "rejeitada"
      aluno_status: "pendente" | "aprovado" | "bloqueado"
      app_role: "mestre" | "aluno" | "super" | "admin_limitado"
      exame_status: "agendado" | "aprovado" | "reprovado" | "cancelado"
      mensalidade_status: "pendente" | "pago" | "atrasado"
      plano_tipo: "basico" | "intermediario" | "completo"
      tecnica_categoria: "defesas" | "socos" | "chutes" | "quedas"
      turma_tipo: "infantil" | "juvenil" | "adulto"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      academia_status: ["pendente", "teste", "ativa", "suspensa", "rejeitada"],
      aluno_status: ["pendente", "aprovado", "bloqueado"],
      app_role: ["mestre", "aluno", "super", "admin_limitado"],
      exame_status: ["agendado", "aprovado", "reprovado", "cancelado"],
      mensalidade_status: ["pendente", "pago", "atrasado"],
      plano_tipo: ["basico", "intermediario", "completo"],
      tecnica_categoria: ["defesas", "socos", "chutes", "quedas"],
      turma_tipo: ["infantil", "juvenil", "adulto"],
    },
  },
} as const
