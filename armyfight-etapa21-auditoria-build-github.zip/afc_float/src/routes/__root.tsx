import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { AfcProvider, useAfc } from "@/lib/afc";
import { AuthScreen, StatusScreen } from "@/components/afc-auth";
import { ComunicadoBanner, SuporteButton } from "@/components/afc-suporte";
import { PwaInstall } from "@/components/pwa-install";
import { AfcFloatingMenu } from "@/components/afc-floating-menu";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { name: "theme-color", content: "#0d100d" },
      { name: "mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-capable", content: "yes" },
      { name: "apple-mobile-web-app-status-bar-style", content: "black-translucent" },
      { name: "apple-mobile-web-app-title", content: "Army Fight Club" },
      { title: "Army Fight Club — Gestão para academias de artes marciais" },
      {
        name: "description",
        content:
          "Army Fight Club: plataforma de gestão para academias de artes marciais — alunos, turmas, presença, graduações e administração.",
      },
      { name: "author", content: "Army Fight Club" },
      { property: "og:title", content: "Army Fight Club" },
      {
        property: "og:description",
        content: "Disciplina, evolução e gestão em uma só plataforma.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "icon", href: "/icons/afc-192.png", type: "image/png", sizes: "192x192" },
      { rel: "apple-touch-icon", href: "/icons/afc-192.png" },
      { rel: "manifest", href: "/manifest.webmanifest" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Oswald:wght@400;600;700&family=Inter:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <AfcProvider>
        <AuthGate />
        <PwaInstall />
      </AfcProvider>
    </QueryClientProvider>
  );
}


function AppStartupScreen() {
  return (
    <main className="relative flex min-h-[100svh] items-center justify-center overflow-hidden bg-[#0d100d] px-6 text-center text-white">
      <div aria-hidden="true" className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(139,150,74,0.18),transparent_58%)]" />
      <div className="relative flex w-full max-w-sm flex-col items-center">
        <img
          src="/icons/afc-512.png"
          alt=""
          className="mb-6 h-28 w-28 rounded-2xl border border-[#a7a66b]/50 shadow-[0_0_48px_rgba(139,150,74,0.18)]"
          width={112}
          height={112}
        />
        <p className="font-['Oswald',sans-serif] text-3xl font-bold uppercase tracking-[0.18em]">Army Fight Club</p>
        <p className="mt-2 text-xs uppercase tracking-[0.28em] text-[#b4b99a]">Disciplina • Evolução • Honra</p>
        <div className="mt-10 h-1 w-36 overflow-hidden rounded-full bg-white/10" role="status" aria-label="Carregando aplicativo">
          <div className="h-full w-1/2 animate-pulse rounded-full bg-[#a7a66b]" />
        </div>
        <p className="mt-3 text-xs text-white/50">Preparando seu acesso…</p>
      </div>
    </main>
  );
}

function AuthGate() {
  const { hydrated, user, profile, isMestre, isSuper } = useAfc();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isPortal =
    pathname === "/" ||
    pathname === "/entrar" ||
    pathname === "/super" ||
    pathname === "/criar-academia";

  if (isPortal) return <Outlet />;
  if (!hydrated) return <AppStartupScreen />;
  if (!user) return <AuthScreen />;
  if (!isMestre && !isSuper) {
    if (!profile) return <StatusScreen variant="pendente" />;
    if (profile.status === "pendente") return <StatusScreen variant="pendente" />;
    if (profile.status === "bloqueado") return <StatusScreen variant="bloqueado" />;
    if (profile.bloqueado_inadimplencia) return <StatusScreen variant="inadimplente" />;
  }
  return (
    <>
      <ComunicadoBanner />
      <Outlet />
      <SuporteButton />
      <AfcFloatingMenu isMestre={isMestre} isSuper={isSuper} />
      <div
        style={{
          position: "fixed",
          bottom: 6,
          right: 10,
          fontSize: 10,
          letterSpacing: "0.15em",
          textTransform: "uppercase",
          color: "rgba(168,164,143,0.55)",
          fontFamily: "'Oswald', sans-serif",
          pointerEvents: "none",
          zIndex: 30,
        }}
      >
        Feito por Lucas
      </div>
    </>
  );
}
