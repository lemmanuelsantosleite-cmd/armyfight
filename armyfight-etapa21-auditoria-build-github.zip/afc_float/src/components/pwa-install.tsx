import { useEffect, useState } from "react";
import { Download, X, Share } from "lucide-react";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

/** Adds a small, unobtrusive install action when the browser supports PWA installation. */
export function PwaInstall() {
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [showInstallHelp, setShowInstallHelp] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in window.navigator &&
        Boolean((window.navigator as Navigator & { standalone?: boolean }).standalone));
    setIsInstalled(standalone);
    const userAgent = window.navigator.userAgent;
    setIsIOS(/iphone|ipad|ipod/i.test(userAgent));
    setIsAndroid(/android/i.test(userAgent));

    const onBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const onInstalled = () => {
      setIsInstalled(true);
      setInstallPrompt(null);
      setShowInstallHelp(false);
    };

    window.addEventListener("beforeinstallprompt", onBeforeInstallPrompt);
    window.addEventListener("appinstalled", onInstalled);

    if ("serviceWorker" in navigator && window.location.protocol === "https:") {
      navigator.serviceWorker.register("/sw.js").catch((error) => {
        console.error("Army Fight Club: falha ao registrar service worker", error);
      });
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstallPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (isInstalled || dismissed || (!installPrompt && !isIOS && !isAndroid)) return null;

  const install = async () => {
    if (installPrompt) {
      await installPrompt.prompt();
      const choice = await installPrompt.userChoice;
      if (choice.outcome === "accepted") setInstallPrompt(null);
      return;
    }
    setShowInstallHelp(true);
  };

  return (
    <>
      <aside
        className="fixed bottom-4 left-3 right-3 z-[100] mx-auto flex max-w-md items-center gap-3 rounded-xl border border-border bg-background/95 p-3 text-foreground shadow-2xl backdrop-blur"
        aria-label="Instalar Army Fight Club"
      >
        <img src="/icons/afc-192.png" alt="" className="h-11 w-11 rounded-lg" />
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold">Army Fight Club</p>
          <p className="text-xs text-muted-foreground">Adicione à tela inicial para abrir como app.</p>
        </div>
        <button
          type="button"
          onClick={install}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground"
        >
          {isIOS ? <Share size={16} /> : <Download size={16} />}
          Instalar
        </button>
        <button
          type="button"
          onClick={() => setDismissed(true)}
          aria-label="Fechar sugestão de instalação"
          className="rounded-md p-1 text-muted-foreground hover:bg-muted"
        >
          <X size={16} />
        </button>
      </aside>

      {showInstallHelp && (
        <div className="fixed inset-0 z-[110] flex items-end justify-center bg-black/60 p-4 sm:items-center">
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="pwa-ios-title"
            className="w-full max-w-sm rounded-2xl border border-border bg-background p-5 text-foreground shadow-xl"
          >
            <h2 id="pwa-ios-title" className="text-lg font-bold">Adicionar à tela inicial</h2>
            {isIOS ? (
              <p className="mt-2 text-sm text-muted-foreground">
                No Safari, toque em <strong>Compartilhar</strong> e depois em <strong>Adicionar à Tela de Início</strong>.
              </p>
            ) : (
              <p className="mt-2 text-sm text-muted-foreground">
                No Chrome para Android, abra o menu <strong>⋮</strong> e procure <strong>Instalar app</strong> ou <strong>Adicionar à tela inicial</strong>. A opção pode variar conforme o navegador e a versão do site.
              </p>
            )}
            <button
              type="button"
              onClick={() => setShowInstallHelp(false)}
              className="mt-4 w-full rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground"
            >
              Entendi
            </button>
          </section>
        </div>
      )}
    </>
  );
}
