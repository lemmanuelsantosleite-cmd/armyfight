import { useEffect, useRef, useState } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { BookOpen, ChevronUp, Dumbbell, Home, LayoutDashboard, Menu, ShieldCheck, Users, X } from "lucide-react";

type Props = { isMestre: boolean; isSuper: boolean };
type Item = { label: string; to: "/aluno" | "/admin" | "/academia" | "/hub"; icon: typeof Home };

export function AfcFloatingMenu({ isMestre, isSuper }: Props) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const items: Item[] = isSuper
    ? [
        { label: "Painel", to: "/hub", icon: LayoutDashboard },
        { label: "Academia", to: "/academia", icon: Dumbbell },
      ]
    : isMestre
      ? [
          { label: "Painel", to: "/admin", icon: LayoutDashboard },
          { label: "Alunos", to: "/admin", icon: Users },
          { label: "Academia", to: "/academia", icon: Dumbbell },
        ]
      : [
          { label: "Início", to: "/aluno", icon: Home },
          { label: "Técnicas e faixas", to: "/academia", icon: BookOpen },
        ];

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: PointerEvent) => {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) setOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  useEffect(() => setOpen(false), [pathname]);

  return (
    <div
      ref={rootRef}
      className="afc-floating-menu fixed left-1/2 z-[90] -translate-x-1/2"
      style={{ bottom: "calc(1rem + env(safe-area-inset-bottom, 0px))" }}
    >
      <AnimatePresence>
        {open && (
          <motion.nav
            aria-label="Navegação rápida"
            id="afc-floating-menu-panel"
            initial={reduceMotion ? false : { opacity: 0, y: 12, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reduceMotion ? undefined : { opacity: 0, y: 8, scale: 0.96 }}
            transition={{ duration: reduceMotion ? 0 : 0.2 }}
            className="mb-3 flex min-w-[220px] flex-col gap-1 rounded-2xl border border-[#9b9c68]/40 bg-[#10130f]/95 p-2 text-white shadow-[0_16px_50px_rgba(0,0,0,0.48)] backdrop-blur-xl"
          >
            <div className="px-3 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-[0.22em] text-[#b6b88a]">
              {isSuper ? "Comando central" : isMestre ? "Área do mestre" : "Área do aluno"}
            </div>
            {items.map(({ label, to, icon: Icon }) => {
              const active = pathname === to;
              return (
                <Link
                  key={`${label}-${to}`}
                  to={to}
                  onClick={() => setOpen(false)}
                  aria-current={active ? "page" : undefined}
                  className={`flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm transition-colors ${active ? "bg-[#8d9258]/20 text-[#e2df9c]" : "text-white/80 hover:bg-white/[0.07] hover:text-white"}`}
                >
                  <Icon size={17} aria-hidden="true" />
                  <span>{label}</span>
                  {active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-[#c7c77b]" />}
                </Link>
              );
            })}
            <div className="mt-1 flex items-center gap-2 border-t border-white/10 px-3 py-2 text-[10px] uppercase tracking-[0.16em] text-white/40">
              <ShieldCheck size={13} aria-hidden="true" /> Army Fight Club
            </div>
          </motion.nav>
        )}
      </AnimatePresence>

      <motion.button
        type="button"
        onClick={() => setOpen((value) => !value)}
        aria-expanded={open}
        aria-controls="afc-floating-menu-panel"
        aria-label={open ? "Fechar navegação rápida" : "Abrir navegação rápida"}
        whileTap={reduceMotion ? undefined : { scale: 0.96 }}
        className="flex h-12 items-center gap-3 rounded-full border border-[#b8b77a]/50 bg-[#11140f]/95 px-4 text-white shadow-[0_8px_30px_rgba(0,0,0,0.4)] backdrop-blur-xl transition-colors hover:border-[#d0ce8c]/80"
      >
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#8c9157]/20 text-[#d5d49a]">
          {open ? <X size={16} /> : <Menu size={16} />}
        </span>
        <span className="text-xs font-semibold uppercase tracking-[0.18em]">Menu</span>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: reduceMotion ? 0 : 0.18 }} className="text-[#d5d49a]">
          <ChevronUp size={15} />
        </motion.span>
      </motion.button>
    </div>
  );
}
