import React, { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";

type ContainerScrollProps = {
  titleComponent?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
};

/**
 * Compact scroll animation adapted for the Army Fight Club React/Vite app.
 * Keeps the effect lightweight and avoids the oversized demo layout.
 */
export function ContainerScroll({ titleComponent, children, className = "" }: ContainerScrollProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });
  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], prefersReducedMotion ? [0, 0, 0] : [4, 0, -2]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], prefersReducedMotion ? [1, 1, 1] : [0.97, 1, 0.99]);
  const opacity = useTransform(scrollYProgress, [0, 0.12, 0.88, 1], prefersReducedMotion ? [1, 1, 1, 1] : [0.75, 1, 1, 0.92]);

  return (
    <div ref={containerRef} className={className}>
      {titleComponent ? <div className="relative z-10">{titleComponent}</div> : null}
      <motion.div
        style={{ rotateX, scale, opacity, transformPerspective: 1200 }}
        className="will-change-transform"
      >
        {children}
      </motion.div>
    </div>
  );
}
