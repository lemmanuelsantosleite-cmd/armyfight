import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";

/**
 * Autentica o Super Administrador sem devolver o e-mail interno ao navegador.
 * A resposta só contém os tokens de sessão após validar senha e cargo.
 */
export const entrarSuper = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ usuario: z.string().trim().min(1).max(120), senha: z.string().min(1).max(128) }).parse(input),
  )
  .handler(async ({ data }) => {
    const invalido = "Usuário ou senha inválidos.";
    const supabaseUrl = process.env.SUPABASE_URL;
    const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;
    if (!supabaseUrl || !publishableKey) {
      console.error("Configuração pública do Supabase ausente no servidor.");
      throw new Error("Não foi possível iniciar o login. Tente novamente.");
    }

    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      // Paginar explicitamente: a API PostgREST pode limitar uma resposta,
      // então uma consulta única poderia omitir contas Super em instalações grandes.
      const superIds = new Set<string>();
      const rolePageSize = 500;
      for (let offset = 0; ; offset += rolePageSize) {
        const { data: roles, error: rolesError } = await supabaseAdmin
          .from("user_roles")
          .select("user_id")
          .eq("role", "super")
          .range(offset, offset + rolePageSize - 1);
        if (rolesError) {
          console.error("Falha ao consultar permissões de Super Administrador.", rolesError);
          throw new Error("Não foi possível iniciar o login. Tente novamente.");
        }
        for (const role of roles ?? []) superIds.add((role as { user_id: string }).user_id);
        if (!roles || roles.length < rolePageSize) break;
      }
      if (superIds.size === 0) throw new Error(invalido);

      const alvo = data.usuario.trim().toLowerCase();
      let emailEncontrado: string | null = null;
      let encontrouFim = false;
      for (let page = 1; page <= 20; page++) {
        const { data: list, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
        if (error) {
          console.error("Falha ao procurar conta de Super Administrador.", error);
          throw new Error("Não foi possível iniciar o login. Tente novamente.");
        }
        for (const u of list.users) {
          if (!superIds.has(u.id) || !u.email) continue;
          const email = u.email.toLowerCase();
          const local = email.split("@")[0] ?? "";
          const nome = String((u.user_metadata as { nome?: string } | null)?.nome ?? "").trim().toLowerCase();
          if (alvo === email || alvo === local || alvo === nome || local.startsWith(`${alvo}.`)) {
            emailEncontrado = u.email;
            break;
          }
        }
        if (emailEncontrado) break;
        if (list.users.length < 200) {
          encontrouFim = true;
          break;
        }
      }
      if (!emailEncontrado) {
        if (!encontrouFim) {
          console.error("A busca de contas Super atingiu o limite de paginação.");
          throw new Error("Não foi possível iniciar o login. Tente novamente.");
        }
        throw new Error(invalido);
      }

      // O cliente não persiste sessão no servidor; os tokens só são retornados após autenticação válida.
      const authClient = createClient(supabaseUrl, publishableKey, {
        auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
      });
      const { data: signed, error: signInError } = await authClient.auth.signInWithPassword({
        email: emailEncontrado,
        password: data.senha,
      });
      if (signInError || !signed.user || !signed.session) throw new Error(invalido);
      if (!superIds.has(signed.user.id)) throw new Error(invalido);
      return {
        session: {
          access_token: signed.session.access_token,
          refresh_token: signed.session.refresh_token,
        },
      };
    } catch (error) {
      if (error instanceof Error && (error.message === invalido || error.message === "Não foi possível iniciar o login. Tente novamente.")) {
        throw error;
      }
      console.error("Falha inesperada no login do Super Administrador.", error);
      throw new Error("Não foi possível iniciar o login. Tente novamente.");
    }
  });
