import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { nomeSlug, alunoEmailFor } from "@/lib/slug";

/** Solicitação de cadastro do aluno: apenas o nome completo. */
export const solicitarCadastro = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        nome: z.string().trim().min(3).max(120),
        academiaId: z.string().uuid(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const slug = nomeSlug(data.nome);
    if (slug.length < 3) throw new Error("Informe seu nome completo.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: academia, error: academiaError } = await supabaseAdmin
      .from("academias")
      .select("id, slug")
      .eq("id", data.academiaId)
      .maybeSingle();
    if (academiaError) {
      console.error("Falha ao consultar academia no pedido de cadastro.", academiaError);
      throw new Error("Não foi possível validar a academia. Tente novamente.");
    }
    if (!academia) throw new Error("Academia inválida. Selecione novamente sua academia.");

    const { data: existing, error: existingError } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("academia_id", academia.id)
      .eq("nome_slug", slug)
      .maybeSingle();
    if (existingError) {
      console.error("Falha ao verificar cadastro existente de aluno.", existingError);
      throw new Error("Não foi possível verificar o cadastro. Tente novamente.");
    }
    if (existing) throw new Error("Já existe um cadastro com esse nome completo.");

    const { error } = await supabaseAdmin.auth.admin.createUser({
      email: alunoEmailFor(data.nome, academia.slug),
      password: crypto.randomUUID() + crypto.randomUUID(),
      email_confirm: true,
      user_metadata: { nome: data.nome.trim(), academia_id: academia.id },
    });
    if (error) {
      if (/already/i.test(error.message)) throw new Error("Já existe um cadastro com esse nome completo.");
      console.error("Falha ao criar conta de aluno.", error);
      throw new Error("Não foi possível concluir o cadastro. Confira os dados e tente novamente.");
    }
    return { ok: true as const };
  });

async function assertMestre(context: { supabase: any; userId: string }) {
  const { data: roles, error } = await context.supabase
    .from("user_roles")
    .select("role, academia_id")
    .eq("user_id", context.userId);

  if (error) throw new Error("Não foi possível validar as permissões.");

  const roleRows = (roles ?? []) as { role: string; academia_id: string | null }[];
  const isSuper = roleRows.some((r) => r.role === "super");
  const mestreRole = roleRows.find((r) => r.role === "mestre");
  if (!isSuper && !mestreRole) throw new Error("Forbidden");

  let academiaId = mestreRole?.academia_id ?? null;
  if (!isSuper && !academiaId) {
    const { data: ownProfile, error: profileError } = await context.supabase
      .from("profiles")
      .select("academia_id")
      .eq("id", context.userId)
      .maybeSingle();
    if (profileError) throw new Error("Não foi possível validar a academia do usuário.");
    academiaId = ownProfile?.academia_id ?? null;
  }

  return { isSuper, academiaId };
}

/** Impede que um mestre altere contas pertencentes a outra academia. */
async function assertAlunoDaAcademia(
  context: { supabase: any },
  alunoId: string,
  actor: { isSuper: boolean; academiaId: string | null },
) {
  const { data: profile, error } = await context.supabase
    .from("profiles")
    .select("id, academia_id")
    .eq("id", alunoId)
    .maybeSingle();

  if (error || !profile) throw new Error("Aluno não encontrado ou sem permissão.");
  if (!actor.isSuper && (!actor.academiaId || profile.academia_id !== actor.academiaId)) {
    throw new Error("Você não tem permissão para alterar um aluno de outra academia.");
  }
}

/** Somente o Mestre cria/redefine a senha de um aluno. */
export const definirSenhaAluno = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({ alunoId: z.string().uuid(), senha: z.string().min(6).max(72) })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const actor = await assertMestre(context);
    await assertAlunoDaAcademia(context, data.alunoId, actor);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.alunoId, {
      password: data.senha,
      email_confirm: true,
    });
    if (error) {
      console.error("Falha ao redefinir senha de aluno.", error);
      throw new Error("Não foi possível atualizar a senha do aluno. Tente novamente.");
    }
    return { ok: true as const };
  });

/** Rejeita/remove definitivamente uma solicitação de cadastro. */
export const rejeitarCadastro = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ alunoId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const actor = await assertMestre(context);
    await assertAlunoDaAcademia(context, data.alunoId, actor);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.alunoId);
    if (error) {
      console.error("Falha ao remover cadastro de aluno.", error);
      throw new Error("Não foi possível remover o cadastro. Tente novamente.");
    }
    return { ok: true as const };
  });

/**
 * Resolve o e-mail interno de login a partir do nome completo dentro de UMA
 * academia. O login é sempre nome + senha, e o mesmo nome pode existir em
 * academias diferentes — o `academia_id` é a única chave de separação.
 * Não revela se a conta existe: quando não encontra, devolve o e-mail
 * derivado do nome (a autenticação falhará da mesma forma).
 */
export const resolverLoginAcademia = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({ nome: z.string().trim().min(3).max(120), academiaId: z.string().uuid() })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const slugNome = nomeSlug(data.nome);
    if (slugNome.length < 3) throw new Error("Informe seu nome completo.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: academia, error: academiaError } = await supabaseAdmin
      .from("academias")
      .select("id, slug")
      .eq("id", data.academiaId)
      .maybeSingle();
    if (academiaError) {
      console.error("Falha ao resolver academia para login.", academiaError);
      throw new Error("Não foi possível iniciar o login. Tente novamente.");
    }

    // Não consulte profiles aqui: isso evita usar este endpoint público para
    // enumerar perfis ou e-mails. Para academia inexistente, o fallback mantém
    // a resposta sem revelar se a academia existe.
    return { email: alunoEmailFor(data.nome, academia?.slug ?? null) };
  });
