import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { nomeSlug } from "@/lib/slug";

/**
 * Solicitação pública de criação de academia. A academia nasce vazia: sem
 * faixas, técnicas, alunos ou identidade visual — o Mestre monta tudo depois.
 * Fica com status `pendente` até a liberação do Super Administrador.
 */
export const solicitarAcademia = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        nome: z.string().trim().min(3).max(120),
        modalidade: z.string().trim().min(2).max(80),
        cidade: z.string().trim().max(120).optional().default(""),
        responsavel: z.string().trim().min(3).max(120),
        email: z.string().trim().email().max(160),
        telefone: z.string().trim().max(40).optional().default(""),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const base = nomeSlug(data.nome);
    if (base.length < 3) {
      throw new Error("O nome da academia precisa conter pelo menos três letras ou números.");
    }
    let slug = base;
    let slugDisponivel = false;

    for (let i = 1; i <= 50; i++) {
      const candidato = i === 1 ? base : `${base}-${i}`;
      const { data: existing, error: lookupError } = await supabaseAdmin
        .from("academias")
        .select("id")
        .eq("slug", candidato)
        .maybeSingle();

      // Não trate falha de consulta como se o slug estivesse livre.
      if (lookupError) {
        console.error("Falha ao verificar disponibilidade do slug da academia.", lookupError);
        throw new Error("Não foi possível validar o nome da academia. Tente novamente.");
      }

      if (!existing) {
        slug = candidato;
        slugDisponivel = true;
        break;
      }
    }

    if (!slugDisponivel) {
      throw new Error("Não foi possível reservar um identificador para esta academia. Tente outro nome.");
    }

    const { error } = await supabaseAdmin.from("academias").insert({
      nome: data.nome,
      slug,
      modalidade: data.modalidade,
      endereco: data.cidade,
      email: data.email,
      telefone: data.telefone,
      status: "pendente",
      plano: "basico",
      max_alunos: 50,
      observacao: `Solicitada por ${data.responsavel}`,
    });
    if (error) {
      // A consulta prévia não elimina corrida entre duas solicitações simultâneas.
      // O índice UNIQUE do banco continua sendo a proteção definitiva.
      if (error.code === "23505") {
        throw new Error("Esse identificador acabou de ser usado. Tente solicitar novamente.");
      }
      console.error("Falha ao registrar solicitação de academia.", error);
      throw new Error("Não foi possível enviar a solicitação. Tente novamente.");
    }
    return { ok: true as const };
  });
