# Etapa 4 — revisão e três correções adicionais

## Escopo
Revisão estática do código do projeto Martial Hub / Army Fight Club. Nenhuma conexão com banco real foi feita e nenhuma migration foi executada.

## Correção 1 — corrida na criação de academia
**Arquivo:** `src/lib/academias.functions.ts`

A busca prévia do slug não impede duas solicitações simultâneas de escolherem o mesmo slug. O banco já define `academias.slug` como `UNIQUE`, então agora uma violação `23505` retorna uma mensagem amigável, e outros erros de inserção são registrados no servidor sem expor a mensagem bruta do banco ao usuário.

## Correção 2 — erros ignorados no pedido de cadastro de aluno
**Arquivo:** `src/lib/alunos.functions.ts`, função `solicitarCadastro`

Antes, falhas ao consultar a academia ou verificar um cadastro existente eram ignoradas. Isso poderia produzir uma resposta incorreta ou avançar para criação de usuário sem concluir as verificações. Agora ambas as consultas verificam `error`, registram o detalhe apenas no servidor e interrompem a operação com mensagem segura.

## Correção 3 — erros ignorados durante a resolução do login
**Arquivo:** `src/lib/alunos.functions.ts`, função `resolverLoginAcademia`

Antes, falhas de consulta à academia/perfil podiam ser tratadas como ausência de registro e gerar um e-mail de fallback, confundindo indisponibilidade do banco com credenciais inexistentes. Agora a função distingue erro de consulta de resultado vazio e informa que não foi possível iniciar o login.

## Riscos ainda em aberto
- `solicitarCadastro` continua sendo uma função pública e precisa de proteção contra abuso (limitação de frequência, CAPTCHA ou fluxo de aprovação), idealmente sem bloquear alunos legítimos.
- A verificação de nome antes da criação de usuário também tem uma janela de concorrência. A restrição única em `profiles(academia_id, nome_slug)` ajuda no banco, mas a criação do usuário Auth e a criação/associação do perfil devem ser tratadas como um fluxo consistente para evitar contas órfãs. Isso exige analisar os triggers e o fluxo de cadastro antes de alterar.
- `resolveSuperEmail` continua retornando e-mail de uma conta privilegiada com base em identificador público. A correção segura depende de redesenhar o login de Super, porque simplesmente ocultar o e-mail pode quebrar a autenticação atual.

## Validação
- Revisão estática das alterações e dos fluxos envolvidos.
- Ainda não foi possível executar lint/build/testes: as dependências (`node_modules`) não estão instaladas nesta cópia e não foi confirmada uma instalação funcional.
- Não é uma validação de runtime nem prova de comportamento no Supabase em produção.
