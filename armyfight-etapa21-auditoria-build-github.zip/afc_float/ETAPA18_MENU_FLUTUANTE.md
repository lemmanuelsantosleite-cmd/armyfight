# Etapa 18 — Menu flutuante AFC

## O que mudou
- Adicionado `src/components/afc-floating-menu.tsx`, navegação flutuante com animação discreta e paleta preto/oliva/dourado.
- Integrado ao `AuthGate` em `src/routes/__root.tsx`, apenas no layout autenticado que já passa pelos controles de acesso existentes.
- Itens variam conforme o papel informado pelo contexto: aluno (`/aluno`, `/academia`), mestre (`/admin`, `/academia`) e superusuário (`/hub`, `/academia`).
- Fecha ao navegar, clicar fora ou pressionar Escape; inclui rótulos acessíveis, suporte a preferência de movimento reduzido e posicionamento com safe-area para dispositivos móveis.

## Limites conhecidos
- O menu é apenas navegação visual. Não substitui as regras de autorização do servidor/RLS.
- Os itens reutilizam rotas já presentes no projeto; por isso “Alunos” leva ao painel `/admin`, não a uma página nova exclusiva.
- Build e testes de navegador não foram executados neste ambiente porque `node_modules` não está presente. Testar em desenvolvimento e conferir o comportamento de mestre/aluno antes de publicar.
