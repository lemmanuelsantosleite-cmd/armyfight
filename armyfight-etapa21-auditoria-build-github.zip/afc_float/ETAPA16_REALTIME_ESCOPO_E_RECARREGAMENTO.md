# Etapa 16 — Robustez da sincronização de técnicas

## Alterações
- `reloadTechniques` agora usa o identificador da academia ativa (`academiaId`) com fallback para `tenantId()`.
- Se não houver academia ativa, a lista é limpa em vez de consultar sem um escopo válido.
- Erros na consulta canônica são propagados para não transformar silenciosamente uma falha de rede em uma lista vazia.
- O hook de técnicas recentes filtra eventos Realtime pelo `academia_id` da academia atual, reduzindo recargas provocadas por outras academias.
- A lista canônica continua sendo ordenada por `posicao` após eventos INSERT/UPDATE/DELETE.

## Limites
Essas mudanças foram revisadas estaticamente. Não foi possível confirmar a compilação, as políticas RLS, a configuração de publicação Realtime no projeto Supabase conectado nem o teste de duas sessões/dispositivos, pois as dependências não puderam ser instaladas neste ambiente.
