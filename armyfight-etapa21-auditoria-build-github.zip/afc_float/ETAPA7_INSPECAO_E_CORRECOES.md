# Etapa 7 — inspeção do estado atual e correções pontuais

## Objetivo
Revisar o código que já existe antes de planejar novas funcionalidades, corrigindo problemas pequenos sem mudar o fluxo de autenticação nem alterar banco de produção.

## Correção 1 — login público de aluno não consulta nem devolve e-mail armazenado no perfil
**Arquivo:** `src/lib/alunos.functions.ts` (`resolverLoginAcademia`)

O cadastro cria a conta usando `alunoEmailFor(nome, academia.slug)`. A função de login agora usa a mesma regra determinística e deixa de consultar `profiles.email`. Isso reduz a exposição desnecessária de dados do perfil por uma função pública e evita depender de um valor armazenado que poderia divergir do identificador usado na autenticação.

**Validação pendente:** confirmar com contas reais de teste que todos os usuários existentes foram criados com o mesmo helper e que não há contas antigas com e-mail personalizado. Se houver, será necessário um plano de migração antes de publicar esta mudança.

## Correção 2 — paginação explícita dos cargos Super
**Arquivo:** `src/lib/super.functions.ts`

A consulta de `user_roles` podia depender do limite padrão da API e retornar uma lista parcial. Agora lê os cargos `super` em páginas de 500 registros, interrompendo quando a página vier incompleta ou vazia. Erros de consulta continuam interrompendo o login.

## Correção 3 — validação do identificador de academia
**Arquivo:** `src/lib/academias.functions.ts`

O nome da academia era normalizado para slug, mas nomes compostos apenas por símbolos ou caracteres que fossem removidos podiam produzir identificador vazio/curto. A função agora rejeita esse caso antes de consultar ou inserir no banco.

## Inspeção geral — o que já existe
- Rotas principais: início, entrar, criar academia, hub, Super, administração da academia, aluno e detalhe de faixa.
- Funções server-side: solicitação de academia, solicitação de cadastro de aluno, redefinição de senha, remoção/rejeição de cadastro, resolução do login de aluno, login Super e dados do portal.
- Há middleware de autenticação Supabase para operações administrativas e verificações de cargo/academia nas funções de senha e remoção.
- Há migrations de RLS e funções `SECURITY DEFINER`; uma revisão estática não confirma o estado efetivo do banco remoto.

## Pendências prioritárias para a próxima etapa
1. Implementar proteção persistente contra abuso nas funções públicas (`solicitarCadastro`, `solicitarAcademia`, `resolverLoginAcademia` e `entrarSuper`). Isso exige escolher um mecanismo compartilhado (por exemplo, gateway/edge ou tabela/RPC transacional) e testar sem criar bloqueios fáceis de contornar. Nenhum rate limit em memória foi adicionado.
2. Testar autenticação com Supabase de desenvolvimento: login correto/incorreto, conta sem cargo Super, refresh de sessão, nome repetido em academias diferentes e contas antigas.
3. Testar consistência do cadastro de aluno e trigger `handle_new_user`, incluindo falhas entre criação da conta e criação de perfil.
4. Revisar RLS efetiva e índices/constraints do banco contra migrations completas e, depois, confirmar o estado remoto com acesso autorizado.
5. Criar testes automatizados para autorização multi-academia e mensagens de erro, e integrar build/lint ao processo de validação.

## Testes e limites desta etapa
- Inspeção estática feita nos arquivos alterados e nas rotas/funções existentes.
- Foram executadas verificações de texto para confirmar os três trechos modificados e a remoção da consulta pública ao e-mail de perfil.
- Build, lint e testes automatizados não foram executados: as dependências não estão instaladas nesta cópia e a instalação anterior excedeu o limite de tempo.
- O ZIP foi verificado após criação.
- Nenhuma migration, deploy ou alteração de banco remoto foi executada.
