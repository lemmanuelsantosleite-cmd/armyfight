# Validação do Supabase (somente desenvolvimento)

Este roteiro não executa alterações remotas. Use um projeto Supabase de desenvolvimento separado do projeto de produção.

## Configuração necessária no ambiente local

- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY` (ou a chave pública compatível que o projeto já usa)
- `SUPABASE_SERVICE_ROLE_KEY` apenas no ambiente de servidor; nunca em código cliente, commits ou capturas de tela.

Não compartilhe valores secretos no chat. Configure-os localmente no ambiente de desenvolvimento.

## Checagens de esquema encontradas nas migrações versionadas

- `academias.slug` tem restrição `UNIQUE`.
- `profiles.id` referencia `auth.users(id)`; a tabela tem `nome`, `email`, `status`, e migrações posteriores adicionam `academia_id` e `nome_slug`.
- `user_roles` usa `user_id`, `role` e recebe `academia_id` numa migração posterior.
- `certificados` é criado por uma migração posterior; `techniques` usa esse nome exato no código.
- A função `handle_new_user()` é redefinida em várias migrações. A definição efetiva no banco deve ser comparada com a última migração antes de aplicar qualquer alteração.

## Testes em ambiente de desenvolvimento

1. Aplicar as migrações num projeto Supabase descartável ou local, nunca diretamente em produção.
2. Conferir que `handle_new_user()` cria o perfil e os papéis esperados para novos usuários.
3. Criar solicitações de academia com nomes iguais simultaneamente e confirmar que `slug` continua único.
4. Criar dois alunos com o mesmo nome em academias diferentes; testar também colisão de nomes normalizados na mesma academia.
5. Testar `resolverLoginAcademia` com academia válida/inválida e comparar o email derivado com o email de contas antigas; não migrar contas existentes automaticamente.
6. Testar login de Super correto/incorreto, usuário não-Super e revogação do papel.
7. Testar mestre alterando senha e rejeitando aluno da própria academia, de outra academia e ID inexistente.
8. Forçar falha de consulta do portal e confirmar que o painel apresenta erro, não estatísticas zero enganosas.

## Limites

Este roteiro foi produzido por inspeção estática dos arquivos SQL. Ainda não houve conexão autenticada com um projeto Supabase, execução de migrações, consulta remota nem teste de login real.
