/* Army Fight Club service worker.
 * Cache only public static assets. Never cache navigations, API responses,
 * Supabase requests, authentication pages, or user-specific HTML/data.
 */
const CACHE_NAME = "afc-static-v1";
const PRECACHE_URLS = ["/icons/afc-192.png", "/icons/afc-512.png", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS)).then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key.startsWith("afc-static-") && key !== CACHE_NAME).map((key) => caches.delete(key))),
    ).then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  const isPublicStaticAsset =
    url.pathname.startsWith("/icons/") || url.pathname === "/manifest.webmanifest";
  if (!isPublicStaticAsset) return;

  event.respondWith(
    caches.match(request).then((cached) =>
      cached || fetch(request).then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
        }
        return response;
      }),
    ),
  );
});
