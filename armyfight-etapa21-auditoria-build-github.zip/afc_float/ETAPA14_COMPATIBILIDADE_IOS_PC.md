# Etapa 14 — Compatibilidade iOS e computador

## Resultado esperado
O Army Fight Club é uma aplicação web responsiva com suporte a PWA. A mesma versão pode ser acessada em Android, iPhone/iPad e computadores sem manter bases de código separadas.

- **iPhone/iPad:** abrir o endereço HTTPS no Safari e usar Compartilhar → Adicionar à Tela de Início. O Safari/iOS não oferece o mesmo prompt automático de instalação do Chrome Android.
- **Windows:** Chrome ou Edge; pode ser instalada como aplicativo quando o navegador oferecer a opção.
- **macOS:** Safari (Adicionar ao Dock em versões compatíveis) ou Chrome/Edge.
- **Linux:** Chrome/Chromium/Edge, conforme suporte do navegador.

## Limites importantes
- O PWA não é automaticamente um aplicativo publicado na App Store ou Microsoft Store.
- Login, Supabase, sincronização em tempo real e demais operações de servidor precisam de internet.
- O cache do service worker cobre apenas ícones e manifesto; não declara suporte offline completo.
- A instalação exige publicação em HTTPS, exceto localhost para desenvolvimento.

## Verificação feita nesta etapa
- Confirmado no código: manifest com `display: standalone`, ícones 192/512, metadados Apple e convite de instalação com instruções para iOS.
- A validação em dispositivos físicos e a publicação HTTPS ainda precisam ser feitas; não afirmar que foi testada em iPhone/PC real.
