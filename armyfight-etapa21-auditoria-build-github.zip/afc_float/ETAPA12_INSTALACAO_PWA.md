# Etapa 12 — instalação PWA e experiência de adicionar à tela inicial

## Objetivo
Concluir o comportamento de instalação da versão web como aplicativo no Android, sem criar projeto paralelo nem alterar o projeto do Lovable remotamente.

## Implementado
- Componente `PwaInstall` que escuta `beforeinstallprompt` e mostra a ação de instalação apenas quando relevante.
- Detecta modo standalone e oculta o convite quando o app já está instalado.
- Mostra orientação para iPhone/iPad quando aberto no iOS.
- Registra `/sw.js` em HTTPS.
- Service worker armazena apenas ícones públicos e o manifesto. Não intercepta navegações, páginas autenticadas, APIs nem requisições do Supabase, evitando cache acidental de dados pessoais.
- Adicionado o convite de instalação no shell autenticado da aplicação.

## Limitações conhecidas
- A PWA exige hospedagem HTTPS e publicação do diretório `public`.
- O convite nativo do Android depende do navegador e dos critérios de instalação; não é possível forçá-lo a aparecer.
- O service worker não torna o sistema funcional offline. Login, operações e dados do Supabase continuam dependendo de conexão.
- O ZIP é uma cópia do código-fonte; não sincroniza alterações com Lovable nem publica a aplicação.

## Testes executados nesta etapa
- Revisão estática dos arquivos adicionados e do ponto de integração.
- A compilação ainda precisa ser executada em ambiente com dependências instaladas. Não foi afirmado que a PWA foi instalada/testada em dispositivo real.

## Como validar depois de publicar
1. Abrir a URL HTTPS no Chrome para Android.
2. Confirmar que `/manifest.webmanifest`, `/sw.js` e os dois ícones retornam HTTP 200.
3. No Chrome, usar o menu e escolher `Instalar app` (ou `Adicionar à tela inicial`, conforme a versão).
4. Abrir pelo ícone e confirmar que inicia em modo standalone.
5. Entrar com uma conta de teste e verificar login, navegação e logout online.
6. Confirmar no DevTools/Application que o cache contém apenas ícones e manifesto — não páginas autenticadas nem respostas de API.
