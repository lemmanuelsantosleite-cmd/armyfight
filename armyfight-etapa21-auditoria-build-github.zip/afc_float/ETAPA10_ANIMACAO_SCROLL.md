# Etapa 10 — animação de rolagem do Army Fight Club

## O que foi alterado
- Adicionado `src/components/ui/container-scroll-animation.tsx`, uma versão compacta do efeito de rolagem usando Framer Motion.
- Integrado o efeito ao conteúdo principal do hero da rota `/academia`, mantendo os textos, botões e navegação existentes.
- Adicionada a dependência `framer-motion` ao `package.json`.

## Compatibilidade
O projeto usa React + TanStack Router + Vite + TypeScript + Tailwind CSS 4; não usa Next.js. Por isso, a integração não usa `next/image` nem depende de uma estrutura shadcn completa.

## Próximos passos antes de publicar
1. Executar `bun install` (ou o instalador usado pelo projeto) para atualizar o lockfile e instalar `framer-motion`.
2. Executar `bun run lint` e `bun run build`.
3. Testar a rota `/academia` em celular e desktop e conferir movimento reduzido/acessibilidade.

## Limitação desta entrega
A alteração foi feita no código-fonte do ZIP; não foi sincronizada automaticamente com Lovable/Supabase e não foi possível confirmar uma build sem instalar as dependências. Nenhuma migração ou dado de produção foi alterado.
