# Etapa 11 — preparação para instalação como app (PWA)

## Implementado nesta entrega
- Manifesto `public/manifest.webmanifest` com nome, ícones, escopo, tela inicial e modo `standalone`.
- Ícones Android 192×192 e 512×512 com identidade visual AFC.
- Metadados para tema do navegador e instalação em dispositivos móveis.
- Idioma raiz corrigido para `pt-BR` e metadados gerais atualizados para Army Fight Club.
- `viewport-fit=cover` para melhor aproveitamento de telas móveis.
- Efeito de rolagem respeita a preferência do sistema por movimento reduzido.

## Ainda precisa ser verificado
- A hospedagem final precisa servir o projeto por HTTPS e publicar os arquivos estáticos.
- Validar o manifesto no Chrome/Lighthouse e testar instalação em Android real.
- Esta etapa não adiciona cache offline nem service worker: páginas e ações que consultam Supabase continuam dependendo de conexão.
- Não houve publicação remota nem alterações no banco Supabase.

## Testes desta entrega
- Validar sintaxe JSON do manifesto e dimensões/formato dos ícones.
- A compilação TypeScript/Vite depende da instalação das dependências; a tentativa de instalação excedeu o limite de tempo deste ambiente.
