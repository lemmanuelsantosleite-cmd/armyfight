# Etapa 17 — Matriz de validação funcional

Esta matriz evita marcar funções como aprovadas sem executar o app contra um backend real.

| Área | Teste de aceitação | Estado atual |
|---|---|---|
| Build | Instalar dependências e executar `npm run build` | Bloqueado: instalação excedeu o tempo disponível |
| Lint | Executar `npm run lint` | Pendente |
| Login | Entrar/sair e reabrir sessão | Pendente em navegador real |
| Técnicas | Mestre cria, edita, move e exclui técnica | Pendente com Supabase real |
| Realtime | Aluno em outro dispositivo recebe mudanças sem recarregar | Pendente com duas sessões |
| Isolamento | Evento de outra academia não altera a lista visível | Revisão estática; teste real pendente |
| RLS | Aluno não consegue escrever técnicas por chamada direta | Pendente; verificar políticas no banco real |
| Faixas | Bloqueio de conteúdo acima da graduação | Pendente em sessão real |
| Presença | Registrar e consultar presença | Pendente |
| Mensalidades | Registrar pagamento e validar inadimplência | Pendente |
| Exames/certificados | Criar, consultar e conferir permissões | Pendente |
| PWA | Instalar via HTTPS em Android/iOS/PC | Pendente em dispositivos reais |
| Atualização PWA | Nova versão atualiza sem cache antigo persistente | Pendente em implantação HTTPS |

## Procedimento recomendado para Realtime
1. Entrar como mestre na academia A em um navegador.
2. Entrar como aluno da academia A em outro navegador/dispositivo.
3. Criar uma técnica e confirmar que aparece sem recarregar manualmente.
4. Editar título/descrição, mover posição e excluir; confirmar cada alteração no aluno.
5. Repetir com usuário de academia B e confirmar que os dados não se misturam.
6. No Supabase, confirmar `techniques` na publicação Realtime e conferir RLS para SELECT/INSERT/UPDATE/DELETE.

## Resultado honesto
A Etapa 16 tem alterações de código revisadas. A Etapa 17 documenta os testes de aceitação e bloqueios. Não declarar o aplicativo totalmente testado ou pronto para produção até concluir os testes marcados como pendentes.
