# Etapa 15 — Tela de abertura

Adicionada uma tela de inicialização ao estado em que o aplicativo ainda está verificando a sessão de autenticação. Ela usa o ícone existente, a paleta preta/oliva e o nome Army Fight Club, com indicador visual de carregamento.

A tela não substitui o login, não altera permissões e não aparece quando a sessão já foi hidratada. A imagem usada é o ícone atual do projeto; uma arte de marca exclusiva poderá substituir esse ícone em uma etapa visual posterior.

## Verificação
- Alteração estática revisada no `src/routes/__root.tsx`.
- Compilação ainda não foi executada porque as dependências não estão instaladas neste ambiente.
