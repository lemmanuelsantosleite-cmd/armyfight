# Army Fight Club / Martial Hub — Revisão de RLS, concorrentes e configurações futuras

**Tipo:** revisão estática do código-fonte e comparação documental de recursos divulgados por fornecedores.  
**Não é:** teste de invasão, validação de banco de produção, nem confirmação de que cada fluxo funciona em execução.

## 1. Achado prioritário: políticas antigas e novas podem se somar

No PostgreSQL/Supabase, políticas RLS permissivas para a mesma operação normalmente são combinadas com **OR**. Portanto, criar uma política nova limitada à academia do usuário não torna automaticamente seguras políticas antigas mais amplas que continuem ativas.

Na migração `20260802000628_b84640ff-8439-4201-8243-a4d222066674.sql` há políticas com escopo por `academia_id`/`user_academia`, mas as migrações anteriores também criaram políticas mais gerais, por exemplo:

- `Mestre reads all profiles` e `Mestre updates any profile` em `profiles`;
- `Mestre manages techniques` em `techniques`;
- `Mestre manages mensalidades`, `Mestre manages presencas` e `Mestre manages exames`;
- políticas gerais de mestre para `graduacoes`, `objetivos`, `certificados`, `notificacoes`, `avisos`, `destaques`, `app_settings` e `admin_permissoes`.

**Risco alto a confirmar:** se essas políticas antigas continuam instaladas e permissivas, o escopo novo pode ser contornado porque basta uma política permissiva permitir a operação. Isso é especialmente importante para uma plataforma multiacademia. A conclusão precisa ser confirmada contra o estado real do banco (políticas existentes), porque o repositório de migrações pode não refletir alterações manuais/produção.

### Próxima correção segura
1. Não executar mudanças diretamente no banco publicado.
2. Preparar uma migração revisada que remova/substitua políticas amplas por políticas explicitamente escopadas por academia.
3. Para cada tabela, cobrir SELECT, INSERT, UPDATE e DELETE conforme o papel; validar também `WITH CHECK` em INSERT/UPDATE.
4. Testar com duas academias fictícias, cada uma com mestre, administrador limitado e aluno; tentar leitura e alteração cruzada.
5. Confirmar funções `SECURITY DEFINER`, privilégios `EXECUTE`, triggers e políticas de realtime.

## 2. Inventário inicial de tabelas e políticas vistas nas migrações

| Tabela | Políticas/controle observado no repositório | Verificação necessária |
|---|---|---|
| `profiles` | Próprio perfil e políticas de mestre; depois políticas com academia e Super Admin | **Alta:** políticas gerais antigas podem ampliar acesso; verificar quais campos o usuário pode editar no próprio perfil |
| `user_roles` | Próprias funções e políticas para mestre não-super; migração posterior tenta restringir por academia | **Alta:** revisar OR entre políticas antigas/novas e impedir promoção de privilégios |
| `techniques` | Usuários aprovados leem; mestre gerencia; política posterior adiciona escopo de academia | **Alta:** política geral de mestre pode permitir escrita fora da academia |
| `mensalidades` | Aluno lê as próprias; mestre gerencia | **Alta:** política geral de mestre parece não restringir academia |
| `presencas` | Aluno lê as próprias; mestre gerencia | **Alta:** política geral de mestre parece não restringir academia/turma |
| `exames` | Aluno lê os próprios; mestre gerencia | **Alta:** política geral de mestre parece não restringir academia |
| `app_settings` | Leitura por autenticados; mestre gerencia; migração posterior por academia | **Alta:** validar isolamento e se configurações podem conter dados sensíveis |
| `admin_permissoes` | Mestre lê/gerencia permissões; política por academia adicionada depois | **Alta:** garantir que um mestre não possa conceder permissões em outra academia |
| `graduacoes` | Aluno lê as próprias; mestre gerencia | **Alta:** confirmar que escrita está isolada por academia |
| `objetivos` | Aluno lê os próprios; mestre gerencia | **Alta:** confirmar escopo por academia e por aluno |
| `certificados` | Aluno lê os próprios; mestre gerencia | **Alta:** confirmar escopo, autoria e integridade do histórico |
| `notificacoes` | Aluno lê/atualiza as próprias; mestre gerencia | **Média/alta:** aluno não deve poder alterar campos além do necessário (ex.: apenas lida/não lida) |
| `avisos` | Leitura por autenticados; mestre gerencia; depois escopo por academia | **Alta:** separar avisos globais dos avisos de cada academia |
| `destaques` | Leitura por autenticados; mestre gerencia; depois escopo por academia | **Alta:** definir se é conteúdo global ou por academia |
| `conquistas` | Aluno lê as próprias; mestre gerencia | **Alta:** a política de escrita deve verificar escopo e, idealmente, autoria autorizada |
| `academias` | Público vê academias ativas/teste; usuário vê sua academia; Super Admin gerencia; mestre edita sua academia | Verificar quais campos são públicos e se UPDATE permite somente campos de configuração permitidos |
| `academia_faixas` | Leitura por academia; mestre/Super Admin gerenciam | Verificar se ordem, requisitos e IDs ficam consistentes ao reordenar faixas |
| `comunicados_plataforma` | Usuários leem comunicados ativos; Super Admin gerencia | Confirmar que comunicados inativos não vazam para papéis comuns |
| `suporte_tickets` | Usuário cria/lê os próprios; mestre lê tickets da academia; Super Admin responde | Confirmar UPDATE/DELETE e evitar que o solicitante altere status/resposta administrativa |

As migrações também declaram funções `SECURITY DEFINER` (incluindo helpers de papel/academia e triggers). Cada função precisa ser revisada quanto a `search_path`, validação de identidade, privilégios e possibilidade de contornar RLS. A existência de RLS habilitada, isoladamente, não comprova isolamento correto.

## 3. Matriz de permissões alvo (proposta, não implementação)

| Ação | Super Admin da plataforma | Mestre da academia | Admin limitado | Aluno/responsável |
|---|---|---|---|---|
| Gerenciar academias e planos SaaS | Sim | Não | Não | Não |
| Configurar modalidades, faixas e currículo da própria academia | Suporte excepcional/auditado | Sim | Só se concedido | Não |
| Criar/editar/remover alunos | Suporte excepcional/auditado | Sim | Conforme permissão | Ver apenas dados próprios/dependentes autorizados |
| Lançar presença | Suporte excepcional/auditado | Sim | Conforme permissão | Check-in próprio, se habilitado |
| Registrar exames e graduações | Suporte excepcional/auditado | Sim | Conforme permissão | Consultar histórico próprio |
| Ver dados financeiros | Suporte restrito/auditado | Sim | Conforme permissão explícita | Apenas cobranças e pagamentos próprios/dependentes autorizados |
| Enviar avisos | Comunicados da plataforma | Da própria academia | Conforme permissão | Não |
| Alterar papéis e permissões | Sim, com proteção extra | Papéis não privilegiados da própria academia | Apenas permissões delegadas, sem elevar o próprio cargo | Não |
| Acessar outra academia | Só para suporte justificado e auditado | Não | Não | Não |

**Regra central:** o servidor/banco precisa impor a permissão. Ocultar botões ou redirecionar páginas no React não é controle de segurança.

## 4. Concorrentes — comparação baseada em páginas oficiais

| Produto | Recursos anunciados nas páginas consultadas | Ideia que vale avaliar para o Martial Hub | Cuidado |
|---|---|---|---|
| **Gymdesk** | Gestão de membros, matrículas, presença/check-in, pagamentos, reservas, promoções/faixas, relatórios e check-in por dispositivos móveis | Painel operacional simples, check-in rápido e relatórios de frequência/receita | Validar disponibilidade e integrações para o Brasil; não copiar funções sem necessidade |
| **Kicksite** | Perfis de alunos e famílias, cobrança recorrente, inventário, check-in por PIN/código de barras, histórico de presença, currículo de faixas, eventos de exame, portal móvel, agenda e conteúdo de mídia | Responsáveis/famílias, histórico de graduação, elegibilidade para exame e portal móvel | Pagamentos e comunicação podem depender de fornecedores/país; confirmar custo e suporte local |
| **Spark Membership** | CRM de interessados/aulas experimentais, acompanhamento automatizado, perfis e histórico de faixas, contas familiares, presença, cobrança, calendário, comunicação e ferramentas de marketing | Pipeline de interessados com estados e lembretes; tarefas administrativas e automações futuras | Preço e oferta exibidos podem mudar; páginas de marketing não são validação independente dos resultados alegados |

Fontes oficiais consultadas em 10/10/2026:
- Gymdesk: https://gymdesk.com/software/martial-arts
- Kicksite: https://kicksite.com/martial-arts-management-software/ e https://kicksite.com/faq/
- Spark Membership: https://sparkmembership.com/platform e https://sparkmembership.com/pricing/

A comparação é de funcionalidades anunciadas pelos próprios fornecedores; não é uma avaliação independente nem confirma disponibilidade, meios de pagamento, suporte ou preço final no Brasil.

## 5. Configurações futuras: proposta organizada por prioridade

### P0 — antes de abrir cadastro multiacademia
- Isolamento multi-tenant e matriz de papéis confiável.
- Proteção contra abuso em cadastros públicos e recuperação/login sem revelar e-mails internos.
- Log de auditoria para mudanças sensíveis: quem, quando, academia e ação (sem senhas/tokens).
- Gestão segura de sessões, redefinição de senha e desativação de usuários.
- Tratamento de erros claro; não transformar falhas de banco em listas vazias.

### P1 — configurações básicas por academia
- Nome, logo, cores e dados de contato.
- Fuso horário, idioma e formatos de data/moeda.
- Modalidades praticadas e unidades/filiais, se necessário.
- Faixas, graus, ordem, critérios e currículo customizáveis por modalidade.
- Tipos de turma, capacidade, agenda e regras de presença.
- Papéis/permissões granulares para secretaria/administrador, sem permitir autoelevação.
- Campos opcionais de perfil e regras de privacidade para dados de menores/responsáveis.

### P2 — operações e experiência
- Configuração de mensalidades, vencimentos, descontos e lembretes; registrar pagamentos sem guardar dados de cartão diretamente.
- Check-in por busca/PIN/QR apenas após validar riscos de compartilhamento e falsificação.
- Portal aluno/responsável: horários, presença, avisos, conquistas e progresso.
- Critérios de exame e lista de alunos elegíveis.
- Importação/exportação de alunos e histórico com validação e trilha de auditoria.
- Relatórios por período, turma, frequência e situação financeira.
- Preferências de notificação e consentimento para comunicações.

### P3 — SaaS e diferenciais
- Onboarding guiado de academia, dados de demonstração e migração assistida.
- Planos e limites transparentes; cobrança da plataforma somente quando operação e suporte estiverem estáveis.
- PWA instalável primeiro; decidir app nativo/híbrido depois de validar notificações, offline e distribuição.
- Integrações externas (pagamento, mensagens, calendário) só após checar custo, disponibilidade no Brasil, privacidade e manutenção.
- Backups, monitoramento, plano de incidente e teste periódico de restauração.

## 6. Próxima sequência de trabalho

1. **Confirmar o estado real das políticas** (o repositório não garante que produção esteja igual).
2. Gerar uma migração proposta para substituir políticas antigas amplas; revisão manual antes de aplicar.
3. Preparar testes negativos de isolamento entre duas academias e quatro papéis.
4. Executar instalação/build/lint/typecheck em ambiente controlado; ainda não há resultado confirmado nesta revisão.
5. Corrigir um grupo de problemas por vez e registrar teste de regressão.
6. Só depois adicionar configurações visuais e funcionais por academia.

**Status desta rodada:** análise documental e estática; nenhum SQL foi aplicado a banco e nenhuma tela foi alterada.
