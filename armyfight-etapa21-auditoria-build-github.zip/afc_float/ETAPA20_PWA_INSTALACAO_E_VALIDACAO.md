# Etapa 20 — PWA: fallback de instalação e validação estática

## Mudança realizada
- `src/components/pwa-install.tsx`: quando o navegador Android não dispara `beforeinstallprompt`, o botão de instalação agora pode abrir instruções para instalar pelo menu do Chrome, em vez de ocultar totalmente a ajuda.
- Mantida a instalação nativa por `beforeinstallprompt` quando suportada.
- Mantidas as instruções de Safari/iOS e a detecção de modo standalone.
- Não alterei `start_url: "/"`: essa rota é a entrada pública existente; trocar para uma rota autenticada sem confirmar o fluxo de entrada poderia quebrar a abertura pelo ícone.
- Não alterei o service worker para continuar evitando cache de páginas, rotas autenticadas, API e respostas do Supabase.

## Validações feitas
- A estrutura JSON do manifesto deve ser validada separadamente com `node -e`.
- O service worker deve passar `node --check`.
- Este projeto não contém `node_modules` e não foi possível confirmar build/lint nesta etapa sem instalar as dependências. Não declarar compilação validada.
- Teste real pendente: publicar em HTTPS, abrir no Chrome Android, verificar se os arquivos `/manifest.webmanifest`, `/sw.js`, `/icons/afc-192.png` e `/icons/afc-512.png` retornam corretamente; instalar; abrir pelo ícone; fazer login; navegar; atualizar; confirmar que a sessão e os dados não são afetados por cache.

## Observação
O fallback é instrução manual, não uma garantia de que todo navegador permita instalar. A instalação depende do navegador, HTTPS e dos critérios de instalabilidade da PWA.
