# Etapa 19 — revisão estática da instalação PWA e inicialização

## Escopo revisado
- `public/manifest.webmanifest`
- `public/sw.js`
- `public/icons/afc-192.png` e `public/icons/afc-512.png`
- `src/components/pwa-install.tsx`
- integração do PWA em `src/routes/__root.tsx`
- rotas e configuração geral do router

## Verificações executadas
- Manifesto: JSON válido.
- Service worker: sintaxe JavaScript válida (`node --check`).
- Ícone 192: PNG válido, 192×192.
- Ícone 512: PNG válido, 512×512.
- Integração: o root inclui o manifesto e monta `PwaInstall`; o service worker só é registrado quando o navegador suporta service workers e a página está em HTTPS.
- Privacidade do cache: o service worker limita o cache a ícones públicos e ao manifesto; não intercepta navegações, APIs nem requisições do Supabase.
- Escopo offline: a implementação não promete uso offline das telas autenticadas ou dos dados do Supabase.

## Pontos que ainda não podem ser considerados aprovados
- Não foi possível confirmar compilação (`npm run build`) ou lint (`npm run lint`), pois as dependências não estão instaladas nesta cópia.
- Não foi possível testar instalação real, abertura pelo ícone, login ou navegação em Android/iOS.
- O manifesto usa `start_url: "/"`; ao abrir instalado, começa na página raiz pública. Confirmar se essa é a experiência desejada para a versão publicada.
- O botão nativo de instalação depende de critérios do navegador. Em Android, o convite do componente só aparece depois que o navegador dispara `beforeinstallprompt`; se o evento não ocorrer, o componente não oferece instrução manual para Chrome Android.
- O service worker faz precache com `cache.addAll`. Se qualquer arquivo listado não for servido na publicação, a instalação do service worker falhará; confirmar HTTP 200 para os três recursos.

## Resultado honesto
A revisão estática passou nas verificações acima. Isso **não** comprova que a aplicação compila, que a publicação está correta ou que o PWA foi instalado e testado num aparelho real. Não foram alteradas credenciais, banco de dados ou políticas Supabase.

## Próximos testes depois de publicar em HTTPS
1. Abrir `/manifest.webmanifest`, `/sw.js`, `/icons/afc-192.png` e `/icons/afc-512.png`; confirmar HTTP 200.
2. Abrir a URL no Chrome para Android e verificar se aparece a opção de instalar.
3. Instalar e abrir pelo ícone; confirmar modo standalone e a rota inicial.
4. Entrar com uma conta de teste, navegar pelas telas principais e sair da conta.
5. Atualizar a publicação e confirmar que a versão nova aparece sem limpar manualmente os dados do usuário.
